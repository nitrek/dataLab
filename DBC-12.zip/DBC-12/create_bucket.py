import sys
import subprocess

bucket = sys.argv[1]
cmd = "gsutil mb gs://"+ bucket
proc=subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
