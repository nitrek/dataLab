import boto
import sys

str1 = 'gs_access_key_id = ' + sys.argv[1]
str2 = 'gs_secret_access_key = ' + sys.argv[2]

boto_file_path= boto.pyami.config.BotoConfigLocations[0]
#print boto_file_path

f = open(boto_file_path, 'w+')
f.write('[Credentials]\n')
f.write(str1+ '\n')
f.write(str2+ '\n')
f.write('[Boto]\n')
f.write('https_validate_certificates = True\n')
f.write('[GSUtil]\n')
f.write('content_language = en\n')
f.close()