import boto
import sys

str1 = 'gs_access_key_id = ' + sys.argv[1] + '\n'
str2 = 'gs_secret_access_key = ' + sys.argv[2] + '\n'

boto_file_path= boto.pyami.config.BotoConfigLocations[0]


from tempfile import mkstemp
from shutil import move
from os import remove, close

#write and save the credentials to .boto file
fh, abs_path = mkstemp()
with open(abs_path,'w') as new_file:
    with open(boto_file_path) as old_file:
        for line in old_file:
            if line.__contains__("gs_access_key_id ="):
                new_file.write(line.replace(line, str1))
            elif line.__contains__("gs_secret_access_key ="):
                new_file.write(line.replace(line, str2))
            else:
                new_file.write(line)
close(fh)
#Remove original file
remove(boto_file_path)
#Move new file
move(abs_path, boto_file_path)