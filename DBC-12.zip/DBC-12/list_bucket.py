import sys
import subprocess


sys.stdout.flush()
bucket = sys.argv[1]
cmd = "gsutil ls gs://"+ bucket
proc=subprocess.Popen(cmd, shell=True)
sys.stdout.flush()