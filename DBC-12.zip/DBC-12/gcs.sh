if [ $1 == login ]
then
	#gsutil config -a
	read -p "What is your google access key ID? " gs_id
	read -p "What is your google secret access key? " gs_access_key
	python write_to_boto.py $gs_id $gs_access_key
	echo -n "Credentials saved!"
	sleep 20
elif [ $1 == create ] 
then
	read -p "Create new bucket name: " bucket
    python create_bucket.py $bucket
	sleep 20
elif [ $1 == upload_file ]
then
	read -p "Local file path: " local_file_path
	read -p "Upload to bucket: " bucket
    python upload_file.py $local_file_path $bucket
	sleep 20
elif [ $1 == upload_folder ]
then
	read -p "Local folder path: " local_folder_path
	read -p "Upload to bucket: " bucket
    python upload_folder.py $local_folder_path $bucket	
	sleep 20
elif [ $1 == download_file ]
then
	read -p "Download from bucket: " bucket
	read -p "File name to download: " file_name
	read -p "Download to path: " download_loc
    python download_file.py $bucket $file_name $download_loc
	sleep 20
elif [ $1 == list ]
then
	read -p "List bucket contents of: " bucket
	python list_bucket.py $bucket
elif [ $1 == delete ]
then
	read -p "Bucket name to be deleted: " bucket
    python delete_bucket.py $bucket
else
	echo "Invalid Arguments"
fi