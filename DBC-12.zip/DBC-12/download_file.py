import sys
import subprocess


bucket = sys.argv[1]
file_name= sys.argv[2]
download_loc= sys.argv[3]
cmd = "gsutil cp gs://"+ bucket+"/"+file_name+" "+ download_loc

#cmd = "gsutil cp gs://lavabucket1/hello.txt C:\\Users\\dell\\Desktop\\"
proc=subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)