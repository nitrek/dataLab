import sys
import subprocess

local_file_path = sys.argv[1]
bucket = sys.argv[2]
cmd = "gsutil cp " + local_file_path + " gs://"+ bucket 
proc=subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
