import sys
import subprocess


local_folder_path = sys.argv[1]
bucket = sys.argv[2]
cmd = "gsutil cp -r " + local_folder_path + " gs://"+ bucket 

proc=subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)