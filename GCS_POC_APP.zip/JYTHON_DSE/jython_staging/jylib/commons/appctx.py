from config import default_config as hcd
from commons import logging as hcl

logger = hcl.get_logger(__name__)

__metaclass__ = type

def get_app_ctx(working_dir= None, gcs_bucket=None):
    return AppCtx(working_dir=working_dir, gcs_bucket=gcs_bucket)


def alternative(option1, option2):
    if option1 is not None:
        return option1
    else:
        logger.info(" -- Use default value [{}]", option2)
        return option2

class AppCtx(object):
    def __init__(self, working_dir= None, gcs_bucket=None):
        import os
        
        self.working_dir = alternative(working_dir, os.getcwd())
        logger.info("Current active working directory is [{}].", self.working_dir)

        self.parallel_process = hcd.PARALLEL_PROCESS
        self.thread_number = hcd.THREAD_NUMBER
        self.keep_alive_days = hcd.KEEP_ALIVE_DAYS
      
        
        self.gcs_crypto_key_path = os.path.expanduser(hcd.GCS_CRYPTO_KEY_PATH)
        self.gcs_crypto_path = os.path.expanduser(hcd.GCS_CRYPTO_PATH)
        
        self.gcs_bucket = alternative(gcs_bucket, hcd.GCS_BUCKET)
        logger.info("default gcs_bucket is [{}].", self.gcs_bucket)
         
        logger.info("default gcs crypto key path is [{}], crypto path is [{}].",
                    self.gcs_crypto_key_path, self.gcs_crypto_path)
        self.shell_env_map = os.environ.copy()
        
        
    def update_gcs_cipher(self, gcs_access_key_id, gcs_secret_access_key):

        self.shell_env_map["gs_access_key_id"] = gcs_access_key_id
        self.shell_env_map["gs_secret_access_key"] = gcs_secret_access_key
        self.shell_env_map["project_id"]= "datalab1-159607"
   
        # update shell env map:
        #self.shell_env_map = os.environ.copy()