import sys

from gcs import app_main as gpa

# logger = gcl.get_logger(__name__)


if __name__ == "__main__":
    gpa.main(sys.argv)

print ("module %s Loaded..." % __name__)