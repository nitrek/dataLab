

from commons import logging as hcl
from commons import appctx as hca
from gcs.bucket_operations import GCSHelper
from gcs.bucket_operations import main_cipher
from config import default_config as hcd
from commons.util import lower

import traceback
import sys
import os

logger = hcl.get_logger(__name__)

ACTION_CIPHER="cipher"
ACTION_CREATE = "create"
ACTION_UPLOAD_FILE = "upload_file"
ACTION_UPLOAD_FOLDER= "upload_folder"
ACTION_LIST= "list" 
ACTION_DELETE= "delete"

SUPPORTED_ACTIONS = [ACTION_CIPHER, ACTION_CREATE, ACTION_UPLOAD_FILE, ACTION_UPLOAD_FOLDER, ACTION_LIST, ACTION_DELETE]


def app_help(argv):
    logger.error("Supported arguments are: [{}], but the arguments are: ",
                 " / ".join(SUPPORTED_ACTIONS))
    for idx, arg in enumerate(argv):
        print (idx, arg)
        logger.error("  param[{}] is [{}] ", idx, arg)


def get_arg_values(argv):
    local_path= None
    
    if len(argv) < 2: # the first arg is the py file name, 2nd is action
        logger.error("At least 2 parameters should be provided..")
        sys.exit(-1)
    elif len(argv) == 2:
        action = lower(argv[1])
        if action not in SUPPORTED_ACTIONS:
            app_help(argv)
            sys.exit(-1)
        logger.info("get_arg_values() - Action is [{}]", action)
    else:
        action = lower(argv[1])
        local_path = argv[2] #3rd argument file or folder path
        if action not in SUPPORTED_ACTIONS:
            app_help(argv)
            sys.exit(-1)
        logger.info("get_arg_values() - Action is [{}], File to be upload is [{}]", action, local_path)
    return [action, local_path]
    


def __main(argv, working_dir=None, bucket=None):
    
    action_code,local_path = get_arg_values(argv)
    
    
    app_ctx = hca.get_app_ctx(working_dir=os.getcwd(), gcs_bucket=hcd.GCS_BUCKET)
    print app_ctx
    rc_code = 0
    
    if ACTION_CIPHER == action_code:
        logger.info("Processing action [{}]", ACTION_CREATE)

        rc_code = main_cipher(app_ctx)
        return rc_code

    elif ACTION_CREATE == action_code:
        logger.info("Processing action [{}]", ACTION_CREATE)

        o = GCSHelper(app_ctx)
        rc_code = o.create()
        return rc_code
    elif ACTION_LIST == action_code:
        logger.info("Processing action [{}]", ACTION_CREATE)

        o = GCSHelper(app_ctx)
        rc_code = o.list()
        return rc_code

    elif ACTION_DELETE == action_code:
        logger.info("Processing action [{}]", ACTION_CREATE)
        
        o = GCSHelper(app_ctx)
        rc_code = o.delete()
        return rc_code
        
    elif ACTION_UPLOAD_FILE == action_code:
        logger.info("Processing action [{}]", ACTION_CREATE)
        
        o = GCSHelper(app_ctx)
        rc_code = o.upload_file(local_path)
        return rc_code
        
    elif ACTION_UPLOAD_FILE == action_code:
        logger.info("Processing action [{}]", ACTION_CREATE)
        
        o = GCSHelper(app_ctx)
        rc_code = o.upload_folder(local_path)
        return rc_code

def main(argv):
    rc_code = 0
    try:
        rc_code = __main(argv)
    except:
        rc_code = 1
        logger.error("Error occurred: {}", str(traceback.format_exc()))
        logger.error("Execution info: {}", str(sys.exc_info()[0]))
        raise
    finally:
        if rc_code == 0:
            logger.info("... Programme Ends successfully...")
        else:
            logger.error("... Oooops, Programme Ends, but there were errors ...")
        sys.exit(rc_code)
    