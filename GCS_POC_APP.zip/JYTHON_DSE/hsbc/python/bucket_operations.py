from os.path import expanduser
import os
import sys

import subprocess
from commons import logging as hcl
from commons import process as hcp

from com.lava import CryptoUtils

__metaclass__ = type

logger = hcl.get_logger(__name__) 

class GCSHelper(object):
    def __init__(self, app_ctx):
        self.gcs_bucket = app_ctx.gcs_bucket
        self.p= hcp.Process()
        self.shell_env_map = app_ctx.shell_env_map
        pre_bucket_init(app_ctx)

    def create(self):
        print "inside create   " + self.gcs_bucket
        cmd = "gsutil mb gs://"+ self.gcs_bucket
        
        logger.info("Start to create bucket, by running command: [{}] ", cmd)
        sout, serr, rc = self.p.call(cmd, shell=True, env=self.shell_env_map)
        self.print_command_result(cmd, sout, serr, rc)
        return rc
        
    def delete(self):
        cmd = "gsutil rm -r gs://"+ self.gcs_bucket
        subprocess.Popen(cmd, shell=True)
        logger.info("Start to delete bucket, by running command: [{}] ", cmd)
        sout, serr, rc = self.p.call(cmd, shell=True, env=self.shell_env_map)
        self.print_command_result(cmd, sout, serr, rc)
        
    def ls(self):
        sys.stdout.flush()
        cmd = "gsutil ls gs://"+ self.gcs_bucket
        subprocess.Popen(cmd, shell=True)
        sys.stdout.flush()
        logger.info("Start to list bucket contents, by running command: [{}] ", cmd)
        sout, serr, rc = self.p.call(cmd, shell=True, env=self.shell_env_map)
        self.print_command_result(cmd, sout, serr, rc)
        
        
    def upload_file (self, local_file_path):
        cmd = "gsutil cp " + local_file_path + " gs://"+ self.gcs_bucket 
        subprocess.Popen(cmd, shell=True)
        logger.info("Start to upload file, by running command: [{}] ", cmd)
        sout, serr, rc = self.p.call(cmd, shell=True, env=self.shell_env_map)
        self.print_command_result(cmd, sout, serr, rc)
        
    def upload_folder (self, local_folder_path):
        cmd = "gsutil cp -r " + local_folder_path + " gs://"+ self.gcs_bucket 
        subprocess.Popen(cmd, shell=True)
        logger.info("Start to upload folder, by running command: [{}] ", cmd)
        sout, serr, rc = self.p.call(cmd, shell=True, env=self.shell_env_map)
        self.print_command_result(cmd, sout, serr, rc)
        
        
    def print_command_result(self, cmd, sout, serr, rc):
        if rc == 0:
            logger.info("GCS cli command [{}] was done successfully.", cmd)
        else:
            logger.error("GCS cli command [{}] failed, exit code is [{}], error is: [{}]",
                        cmd, rc, serr)
        

def pre_bucket_init(app_ctx):
    encryption_key = read_key(app_ctx.gcs_crypto_key_path)
    encrypt_key_id, encrypt_access_key = read_aws_crypto(app_ctx.gcs_crypto_path)
    
    # start to decrypt:
    crypto_utils = CryptoUtils.createAESCrypto()
    gcs_access_key_id = crypto_utils.decrypt(CryptoUtils.convertHexString(encrypt_key_id), encryption_key)
    gcs_secret_access_key = crypto_utils.decrypt(CryptoUtils.convertHexString(encrypt_access_key), encryption_key)
    logger.info("Loading gcs access key id & gcs secret access key was done.")
    
    app_ctx.update_gcs_cipher(gcs_access_key_id, gcs_secret_access_key)  
    
    
def read_aws_crypto(fname):
    if not os.path.isfile(fname):
        logger.error("Crypto file [{}] does not exist.", fname)
        raise Exception("Crypto file [" + fname + "] does not exist.")

    with open(fname) as f:
        content = f.readlines()
    logger.info("Crypto file [{}], content = [{}], length is [{}]", fname, content, len(content))
    if content is None or len(content) != 2: # 7 lines, 
        logger.error("malformed crypto file [{}], file should exist and contains 2 lines only.", fname)
        raise Exception("malformed crypto file " + fname + ", file should exist and contains 7 lines only.")
    return content[0].strip(), content[1]


            
def main_cipher(app_ctx):
    error_rc = 0
    try:
        __main_cipher(app_ctx)
        error_rc = 0
    except:
        error_rc = -1  # abnormal exit
        raise
    return error_rc
    

def __main_cipher(app_ctx):
    from java.lang import System
    from java.lang import String
    crypto_utils = CryptoUtils.createAESCrypto()
    
    #encryption_key = crypto_utils.generateKey()
    
    encryption_key = "IAmSecretKeyCode"
    
    logger.info("{}", "#" * 80)
    logger.info("  Start to input GCS access key id & GCS secret acces key ... ")
    logger.info("  P.S. No echo would display back to the console)")
    logger.info("{}", "#" * 80)
    
    ## version 1:
    gcs_access_key_id = raw_input("Please enter GCS access key: ");
    gcs_secret_access_key = raw_input("Please enter GCS secret access key: ");
    
    
    encrypt_key_id = CryptoUtils.toHexString(crypto_utils.encrypt(gcs_access_key_id, encryption_key))
    encrypt_access_key = CryptoUtils.toHexString(crypto_utils.encrypt(gcs_secret_access_key, encryption_key))
    
    write_key(app_ctx.gcs_crypto_key_path, encryption_key)
    write_crypto_creds(app_ctx.gcs_crypto_path, encrypt_key_id, encrypt_access_key )
    
def write_crypto_creds(gcs_crypto_path, encrypt_key_id, encrypt_access_key):

	cmd = "SET BOTO_CONFIG="+gcs_crypto_path
	subprocess.Popen(cmd, shell=True)
	str1 = 'gs_access_key_id = ' + encrypt_key_id
	str2 = 'gs_secret_access_key = ' + encrypt_access_key

	f = open(gcs_crypto_path, 'w+')
	f.write(str1+ '\n')
	f.write(str2)
	f.close()

def write_key(fname, key):
    mkdir_p_dir(fname) # make sure parent path exist.
    with open(fname, 'w') as f:
        f.write(key)
    logger.info("Writing key file [{}] is completed.", fname)
    
    
def read_key(fname):
    if not os.path.isfile(fname):
        logger.error("Key file [{}] does not exist.", fname)
        raise Exception("Key file [" + fname + "] does not exist.")

    with open(fname) as f:
        content = f.readlines()
    if content is None or len(content) != 2: # one line only
        logger.error("malformed crypto file [{}], file should exist and contains 2 line only.", fname)
        raise Exception("malformed crypto file " + fname + ", file should exist and contains 2 line only.")
    return content[0].strip()
    
    
def mkdir_p_dir(fname):
    import errno
    import os
    path = os.path.dirname(fname)
    logger.info("File [{}]'s parent directory is [{}].", fname, path)
    try:
        os.makedirs(path)
        logger.info("Directory [{}] was created successfully.", path)
    except OSError as exc:  # Python >2.5
        if exc.errno == errno.EEXIST and os.path.isdir(path):
            pass
        else:
            logger.error("Failed to create path [{}]", path)
            raise