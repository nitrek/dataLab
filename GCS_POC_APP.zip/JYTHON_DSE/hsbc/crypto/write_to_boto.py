from os.path import expanduser
import os
import sys
from commons import logging as hcl
import subprocess

from com.lava import CryptoUtils
__metaclass__ = type


logger = hcl.get_logger(__name__)

def main_cipher(app_ctx):
    error_rc = 0
    try:
        __main_cipher(app_ctx)
        error_rc = 0
    except:
        error_rc = -1  # abnormal exit
        raise
    return error_rc
    

def __main_cipher(app_ctx):
    from java.lang import System
    from java.lang import String
    crypto_utils = CryptoUtils.createAESCrypto()
    encryption_key = crypto_utils.generateKey()
    console = System.console()
    logger.info("{}", "#" * 80)
    logger.info("  Start to input AWS access key id & AWS secret acces key ... ")
    logger.info("  P.S. No echo would display back to the console)")
    logger.info("{}", "#" * 80)
    ## version 1:
    aws_access_key_id = console.readPassword("Please enter AWS access key: ")
    aws_secret_access_key = console.readPassword("Please enter AWS secret access key: ")
    encrypt_key_id = CryptoUtils.toHexString(crypto_utils.encrypt(String(aws_access_key_id), encryption_key))
    encrypt_access_key = CryptoUtils.toHexString(crypto_utils.encrypt(String(aws_secret_access_key), encryption_key))
    
    write_key(app_ctx.aws_crypto_key_path, encryption_key)
    write_crypto_creds(app_ctx.aws_crypto_path, encrypt_key_id, encrypt_access_key)
    
    
def write_crypto_creds(creds):
	if len(creds)!=2:
		#log here
		logger.error("Exactly 2 parameters should be passed: gs_access_key_id, gs_secret_access_key")
		sys.exit(-1)
	else:
		boto_file_path = expanduser("~")+"\.boto"
		#boto_file_path= boto.pyami.config.BotoConfigLocations[0]
		#print boto_file_path
		
		cmd = "SET BOTO_CONFIG="+boto_file_path
		subprocess.Popen(cmd, shell=True)
		str1 = 'gs_access_key_id = ' + creds[0]
		str2 = 'gs_secret_access_key = ' + creds[1]

		f = open(boto_file_path, 'w+')
		f.write('[Credentials]\n')
		f.write(str1+ '\n')
		f.write(str2+ '\n')
		f.write('[Boto]\n')
		f.write('https_validate_certificates = True\n')
		f.write('[GSUtil]\n')
		f.write('content_language = en\n')
		f.close()
  
  
def write_key(fname, key):
    mkdir_p_dir(fname) # make sure parent path exist.
    with open(fname, 'w') as f:
        f.write(key)
    logger.info("Writing key file [{}] is completed.", fname)
    
    
def read_key(fname):
    if not os.path.isfile(fname):
        logger.error("Key file [{}] does not exist.", fname)
        raise Exception("Key file [" + fname + "] does not exist.")

    with open(fname) as f:
        content = f.readlines()
    if content is None or len(content) != 1: # one line only
        logger.error("malformed crypto file [{}], file should exist and contains one line only.", fname)
        raise Exception("malformed crypto file " + fname + ", file should exist and contains one line only.")
    return content[0].strip()
    
    
def mkdir_p_dir(fname):
    import errno
    import os
    path = os.path.dirname(fname)
    logger.info("File [{}]'s parent directory is [{}].", fname, path)
    try:
        os.makedirs(path)
        logger.info("Directory [{}] was created successfully.", path)
    except OSError as exc:  # Python >2.5
        if exc.errno == errno.EEXIST and os.path.isdir(path):
            pass
        else:
            logger.error("Failed to create path [{}]", path)
            raise