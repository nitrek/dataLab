import sys

from python import app_main as hpa
from crypto import write_to_boto as hcw
# logger = gcl.get_logger(__name__)


if __name__ == "__main__":
    hpa.main(sys.argv)

print ("module %s Loaded..." % __name__)