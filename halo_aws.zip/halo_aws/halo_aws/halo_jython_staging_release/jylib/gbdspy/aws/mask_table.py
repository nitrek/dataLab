# coding: UTF-8


"""
COPYRIGHT (C) 2017 HSBC GBDS GLTc. ALL RIGHTS RESERVED.

No part of this publication may be reproduced, stored in a retrieval system,
or transmitted, on any form or by any means, electronic, mechanical, photocopying,
recording, or otherwise, without the prior written permission of GBDS.

Created By: Terence Feng
Created On: 2017-02-06

Amendment History:

Amended By       Amended On      Amendment Description
------------     -----------     ---------------------------------------------

"""

from gbdspy.aws import pii_hive as gap
from gbdspy.commons import logging as gcl
from gbdspy.commons.util import gen_salt  ## so that lower() / empty() is visible
from gbdspy.hdp import kerberos as ghk
from java.lang import Runnable
from java.util.concurrent import Executors, TimeUnit

__metaclass__ = type  # use new style class !

logger = gcl.get_logger(__name__)


# class TableMaskingRunnable(Runnable):
#     def __init__(self):
#         pass
#     def run(self):
#         logger.info("Running in run() method.")
#         for x in range(10):
#             print "Hello World"
#             time.sleep(1)
#         logger.info("End of run()")



def process_table_masking(pii_table, salt_value, salt_size, app_ctx):
    """
    Execute masking actions, and log down status.
    :param pii_table:
    :param salt_value:
    :param salt_size:
    :param app_ctx:
    :return:
    """
    serr1, serr2 = "", ""  # If using "None, None", error will occurred for:  "\n".join([serr1, serr2])
    try:
        logger.info("Begin to execute DDL for table [{}] data masking.", pii_table.full_table_name)
        # => step 1: generate table DDL
        ddl = pii_table.generate_table_ddl(app_ctx.stored_format)
        logger.info("ddl is \n{}", ddl)
        sout, serr1, rc = pii_table.execute(ddl)
        app_ctx.rpt.register_mask_ddl(pii_table, sout, serr1, rc)
        # => step 2: generate table masking DML
        dml = pii_table.generate_data_masking_hql(salt_value, salt_size)
        sout, serr2, rc = pii_table.execute(dml)
        app_ctx.rpt.register_mask_dml(pii_table, sout, serr2, rc)
    except (Exception,) as e:
        err_msg = "\n".join([serr1, serr2])
        logger.error("End data masking for table [{}], failed, error message were:\n{}",
                     pii_table.full_table_name, err_msg)
    else:
        logger.info("End data masking for table [{}].", pii_table.full_table_name)


def __main_mask_pii_tables(app_ctx):
    import os
    logger.info("Current active working directory is [{}].", os.getcwd())
    ghk.kinit()
    ghk.klist()
    pii_table_map = app_ctx.pii_table_map
    salt_size = app_ctx.salt_size
    salt_value = gen_salt(8)  # gen_salt is from util.py
    logger.info("There were [{}] tables pending for processing.", len(pii_table_map))
    for key in pii_table_map:
        logger.info("Processing table {}", str(key))
        pii_table = pii_table_map[key]
        process_table_masking(pii_table, salt_value, salt_size, app_ctx)


class TableMaskingRunnable(Runnable):
    def __init__(self, pii_table, salt_value, salt_size, app_ctx):
        self.pii_table = pii_table
        self.salt_value = salt_value
        self.salt_size = salt_size
        self.app_ctx = app_ctx

    def run(self):
        logger.info("In TableMaskingRunnable - Processing table {}", self.pii_table.table_name)
        process_table_masking(self.pii_table, self.salt_value, self.salt_size, self.app_ctx)
        logger.info("In TableMaskingRunnable - End processing table {}", self.pii_table.table_name)


def __main_mask_pii_tables_parallel(app_ctx):
    import os
    logger.info("Current active working directory is [{}].", os.getcwd())
    ghk.kinit()
    ghk.klist()
    pii_table_map = app_ctx.pii_table_map
    salt_size = app_ctx.salt_size
    salt_value = gen_salt(8)  # gen_salt is from util.py
    logger.info("There were [{}] tables pending for processing [Parallel].", len(pii_table_map))
    executor = Executors.newFixedThreadPool(app_ctx.thread_number)
    for key in pii_table_map:
        pii_table = pii_table_map[key]
        runner = TableMaskingRunnable(pii_table, salt_value, salt_size, app_ctx)
        logger.info("Add table [{}] to execution pool.", pii_table.full_table_name)
        executor.execute(runner)

    executor.shutdown()
    executor.awaitTermination(app_ctx.keep_alive_days, TimeUnit.DAYS)
    logger.info("Table masking process has been completed !!")


def main_mask_pii_tables(app_ctx):
    error_rc = 0
    failed_table_count = 0
    try:
        if app_ctx.parallel_process:
            __main_mask_pii_tables_parallel(app_ctx)
        else:  # no threading.
            __main_mask_pii_tables(app_ctx)
        error_rc = 0
    except:
        error_rc = -1  # abnormal exit
        raise
    finally:
        failed_table_count = app_ctx.rpt.report_mask_status()
    return error_rc + failed_table_count


def _init_target_database(database_name, pii_database_map, app_ctx):
    pii_database = None
    if database_name in pii_database_map:
        pii_database = pii_database_map[database_name]
    else:
        pii_database = gap.PIIHiveDatabase(database_name, app_ctx)
        pii_database_map[database_name] = pii_database
    return pii_database


def main_remask_mask_pii_tables(app_ctx):
    logger.info("Start to remask mask_pii tables, cleanup the legacy pii tables in target pii databases first.")
    pii_database_map = {}
    pii_tables = app_ctx.pii_table_map.values()
    failed_count = 0
    for pii_table in pii_tables:
        tgr_database_name = pii_table.target_database_name
        tgr_table_name = pii_table.target_table_name
        pii_database = _init_target_database(tgr_database_name, pii_database_map, app_ctx)
        rc = pii_database.drop_table(tgr_table_name, skipTrash=True)
        if rc == 0:
            logger.info("Drop target pii table [{}.{}] successfully.", tgr_database_name, tgr_table_name)
        else:
            logger.error("Failed to drop target pii table [{}.{}].", tgr_database_name, tgr_table_name)
            failed_count += 1

    if failed_count > 0:
        logger.error("There were [{}] target pii table failed to drop, re-mask action aborted.", failed_count)
        return failed_count
    else:
        logger.info("Target databases' pii tables were cleanup, now start new masking process...")
        return main_mask_pii_tables(app_ctx)


def main_cleanup(app_ctx):
    logger.info("main_cleanup() Starts.")
    for database_name in app_ctx.pii_database_map:
        pii_database = app_ctx.pii_database_map[database_name]
        target_database_name = pii_database.target_database_name
        logger.info("pii hive database name is [{}], target database name is [{}].",
                    database_name, target_database_name)
        targetHiveDatabase = gap.PIIHiveDatabase(target_database_name, app_ctx)
        targetHiveDatabase.drop_database(skipTrash=True)
    logger.info("main_cleanup() Ends.")
    return 0


print ("module %s Loaded..." % __name__)
