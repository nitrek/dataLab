# coding: UTF-8

"""
COPYRIGHT (C) 2017 HSBC GBDS GLTc. ALL RIGHTS RESERVED.

No part of this publication may be reproduced, stored in a retrieval system,
or transmitted, on any form or by any means, electronic, mechanical, photocopying,
recording, or otherwise, without the prior written permission of GBDS.

Created By: Terence Feng
Created On: 2017-02-17

Amendment History:

Amended By       Amended On      Amendment Description
------------     -----------     ---------------------------------------------

"""

import os
import sys

from gbdspy.aws import copy_table as gac
from gbdspy.aws import mask_table as gam
from gbdspy.aws import setting as gas
from gbdspy.commons import logging as gcl
from gbdspy.commons.util import lower

logger = gcl.get_logger(__name__)

ACTION_MASK = "mask"
ACTION_COPY = "copy"
ACTION_RE_MASK = "re-mask"
ACTION_CLEANUP = "cleanup"
SUPPORTED_ACTIONS = [ACTION_MASK, ACTION_COPY, ACTION_RE_MASK, ACTION_CLEANUP]


def app_help(argv):
    logger.error("Supported argument is are: mask / copy / re-mask / cleanup, but the arguments are: ")
    for idx, arg in enumerate(argv):
        # print (idx, arg)
        logger.error("  param[{}] is [{}] ", idx, arg)


def get_action_code(argv):
    if len(argv) != 2:
        app_help(argv)
        sys.exit(-1)
    action = lower(argv[1])
    if action not in SUPPORTED_ACTIONS:
        app_help(argv)
        sys.exit(-1)
    logger.debug("get_action_code() - Action is [{}].", action)
    return action


def __main(argv, working_dir=None, stored_format=None, target_database_postfix=None):
    action_code = get_action_code(argv)
    app_ctx = gas.get_app_ctx(working_dir=os.getcwd(),
                              stored_format=stored_format, target_database_postfix=target_database_postfix)
    app_ctx.print_config_map()
    app_ctx.post_init()  # force init table list.

    rc_code = 0
    if ACTION_MASK == action_code:
        logger.info("Processing action [{}]", ACTION_MASK)
        rc_code = gam.main_mask_pii_tables(app_ctx)
    elif ACTION_COPY == action_code:
        logger.info("Processing action [{}]", ACTION_COPY)
        rc_code = gac.main_copy_none_pii_tables(app_ctx)
    elif ACTION_RE_MASK == action_code:
        # gac.main_copy_none_pii_tables(app_ctx)
        logger.info("Processing action [{}]", ACTION_RE_MASK)
        rc_code = gam.main_remask_mask_pii_tables(app_ctx)
    elif ACTION_CLEANUP == action_code:
        # gac.main_copy_none_pii_tables(app_ctx)
        logger.info("Processing action [{}]", ACTION_CLEANUP)
        rc_code = gam.main_cleanup(app_ctx)
    else:
        logger.error("Unknow action code [{}]", action_code)
    return rc_code


def main(argv, stored_format="text", target_database_postfix="__crypto"):
    rc_code = 0
    try:
        rc_code = __main(argv, stored_format=stored_format, target_database_postfix=target_database_postfix)
    except:
        rc_code = 1
        raise
    finally:
        if rc_code == 0:
            logger.info("... Programme Ends successfully...")
        else:
            logger.error("... Oooops, Programme Ends, but there were errors ...")
        sys.exit(rc_code)


print ("module %s Loaded..." % __name__)
