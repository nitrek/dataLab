# coding: UTF-8


"""
COPYRIGHT (C) 2017 HSBC GBDS GLTc. ALL RIGHTS RESERVED.

No part of this publication may be reproduced, stored in a retrieval system,
or transmitted, on any form or by any means, electronic, mechanical, photocopying,
recording, or otherwise, without the prior written permission of GBDS.

Created By: Terence Feng
Created On: 2017-02-06

Amendment History:

Amended By       Amended On      Amendment Description
------------     -----------     ---------------------------------------------

"""

import abc  # Abstract Base Classes (ABCs)

from gbdspy.commons import logging as gcl
from gbdspy.commons import process as gcp
from gbdspy.commons.util import splitAndStrip, filter_empty_lines, empty

__metaclass__ = type  # use new style class !

logger = gcl.get_logger(__name__)


def get_hive_meta():
    return HiveMetaCLI()


def normalize_name(name):
    """
    Make it strip & lower case
    :param name:
    :return:
    """
    if name is None:
        return None
    else:
        return name.strip().lower()


def get_full_table_name(database_name, table_name):
    if database_name is None or empty(database_name):
        rs = normalize_name(table_name)
        logger.warn("table name [{}] comes without hive database name.", table_name)
    else:
        rs = "{db}.{table}".format(db=normalize_name(database_name), table=normalize_name(table_name))
    return rs


# def pp_columns(hiveColumns):
#     import pprint
#     pprint.pprint([str(column) for column in hiveColumns])
#
#
# def pp_table(hiveTable):
#     import pprint
#     pprint.pprint([str(column) for column in hiveColumns])
#
#
# def pp_database(hiveDatabase):
#     import pprint
#     pprint.pprint([table.full_table_name for table in hiveDatabase.hiveTables])


class HiveColumn(object):
    def __init__(self, column_name, data_type, desc=""):
        self.column_name = normalize_name(column_name)  # column name must be in lower case.
        self.data_type = data_type
        self.desc = desc

    def toMap(self):
        return {"column_name": self.column_name, "data_type": self.data_type, "desc": self.desc}

    def __unicode__(self):
        return "<<HiveColumn: {col} - {type} - {desc}".format(
            col=self.column_name, type=self.data_type, desc=self.desc)

    def __str__(self):
        return unicode(self).encode('utf-8')


class HiveTable(object):
    def __init__(self, database_name, table_name, hiveDatabase=None):
        """
        Init hive table object
        database_name & table_name would be transferred into lower case.
        """
        self.database_name = normalize_name(database_name)
        self.table_name = normalize_name(table_name)
        self.full_table_name = get_full_table_name(database_name, table_name)
        self._hiveDatabase = hiveDatabase
        self.hive_meta = get_hive_meta()
        self._hive_columns = None  # list of column names

    def set_hive_columns(self, hive_columns):
        logger.debug("set_hive_columns is executed, parameter is {}", hive_columns)
        self._hive_columns = hive_columns

    def get_hive_columns(self):
        if self._hive_columns is None:
            self._hive_columns = self.hive_meta.get_hive_columns(self.database_name, self.table_name)
        return self._hive_columns

    hiveColumns = property(get_hive_columns, set_hive_columns)

    def set_hive_database(self, hiveDatabase):
        logger.debug("set_hive_database is executed, type is {}", type(hiveDatabase))
        self._hiveDatabase = hiveDatabase

    def get_hive_database(self):
        if self._hiveDatabase is None:
            # hot fix, make sure basic property could be used, like "location".
            self._hiveDatabase = HiveDatabase(self.database_name)
        return self._hiveDatabase

    hiveDatabase = property(get_hive_database, set_hive_database)

    def get_column_names(self):
        return [column.column_name for column in self.hiveColumns]

    def strkey(self):
        return self.full_table_name

    def execute(self, hql):
        return self.hive_meta.execute(hql)

    def __unicode__(self):
        cols = "\n ".join(self.get_column_names())
        return "<<HiveTable: {db}.{table}:\n {cols}".format(
            db=self.database_name, table=self.table_name, cols=cols)

    def __str__(self):
        return unicode(self).encode('utf-8')


class HiveDatabase(object):
    def __init__(self, database_name):
        self.database_name = normalize_name(database_name)  # string
        self._tables = None
        self._db_info_map = None
        self.hive_meta = get_hive_meta()

    def strkey(self):
        return self.database_name

    def get_hive_tables(self):
        if self._tables is None:
            table_names = self.hive_meta.get_tables(self.database_name)
            self._tables = [HiveTable(self.database_name, table_name, self) for table_name in table_names]
        return self._tables

    hiveTables = property(get_hive_tables)

    def get_database_info(self):
        if self._db_info_map is None:
            self._db_info_map = self.hive_meta.get_database_info(self.database_name)
        return self._db_info_map

    infoMap = property(get_database_info)

    def get_location(self):
        return self.infoMap["location"]

    location = property(get_location)

    def get_full_table_names(self):
        return [table.full_table_name for table in self.hiveTables]

    def get_table_names(self):
        return [table.table_name for table in self.hiveTables]

    def execute(self, hql):
        return self.hive_meta.execute(hql)

    def drop_database(self, skipTrash=False):
        return self.hive_meta.drop_database(self.database_name, skipTrash)

    def drop_table(self, table_name, skipTrash=False):
        return self.hive_meta.drop_table(self.database_name, table_name, skipTrash)

    def __unicode__(self):
        tables = "\n ".join(self.get_full_table_names())
        return "<<HiveDatabase: {db}:\n {tables}".format(db=self.database_name, tables=tables)

    def __str__(self):
        return unicode(self).encode('utf-8')


class HiveMeta(object):
    __metaclass__ = abc.ABCMeta

    @abc.abstractmethod
    def execute(self, hql):
        """
        Execute HQL
        :param hql:
        :return:
        """
        return

    @abc.abstractmethod
    def get_database_info(self, database_name):
        """
        get database info
        :param database_name:
        :return: return map with key: db_name / comment / location / owner_name / owner_type / parameters .
        """
        return

    @abc.abstractmethod
    def get_tables(self, database_name):
        """

        :param database_name:
        :return: a list of table name list
        """
        return

    @abc.abstractmethod
    def get_hive_columns(self, database_name, table_name):
        """

        :param database_name:
        :param table_name:
        :return: a list of HiveColumn.
        """
        return

    @abc.abstractmethod
    def get_table_ddl(self, database_name, table_name):
        """
        Return create table DDL

        :param database_name:
        :param table_name:
        :return:
        """
        return

    @abc.abstractmethod
    def drop_database(self, database_name):
        """
        :param database_name:
        :return: return code
        """
        return

    @abc.abstractmethod
    def drop_table(self, database_name, table_name):
        """
        :param database_name:
        :param table_name:
        :return: return code
        """
        return


HQL_NO_CLI_HEADER = "set hive.cli.print.header=false; "


class HQLFormatter(object):
    def __init__(self, without_header=True):
        self.without_header = without_header

    def format_hql(self, hql):
        fmt_hql = hql
        if not hql.strip().endswith(";"):
            fmt_hql += " ; "
        if self.without_header and HQL_NO_CLI_HEADER not in hql:
            fmt_hql = HQL_NO_CLI_HEADER + fmt_hql
        return fmt_hql

    def desc_table_hql(self, database_name, table_name):
        hql = "desc `{db}`.`{tbl}` ;".format(db=database_name, tbl=table_name)
        return self.format_hql(hql)

    def desc_database_hql(self, database_name):
        hql = "desc database `{db}` ;".format(db=database_name)
        return self.format_hql(hql)

    def show_create_table_hql(self, database_name, table_name):
        hql = "show create table `{db}`.`{tbl}` ;".format(db=database_name, tbl=table_name)
        return self.format_hql(hql)

    def show_tables_hql(self, database_name):
        hql = "show tables in `{db}` ;".format(db=database_name)
        return self.format_hql(hql)

    def drop_database_hql(self, database_name):
        hql = "drop database if exists `{db}` cascade ;".format(db=database_name)
        return self.format_hql(hql)

    def drop_table_hql(self, database_name, table_name):
        hql = "drop table if exists `{db}`.`{tbl}` ;".format(db=database_name, tbl=table_name)
        return self.format_hql(hql)

    def drop_table_skip_trash_hql(self, database_name, table_name):
        hql = "drop table if exists `{db}`.`{tbl}` purge ;".format(db=database_name, tbl=table_name)
        return self.format_hql(hql)


class HiveMetaCLI(HiveMeta):
    def __init__(self, log_sql=False):
        self.log_sql = log_sql
        self.internal_process = gcp.Process()
        self.hql_formatter = HQLFormatter(without_header=True)  # avoid header

    def get_status(self):
        p = self.internal_process
        return p.stdout, p.stderr, p.returnCode

    def execute(self, hql):
        """
        :param hql:
        :return: (sout, serr, rc)
        """
        final_hive_hql = self.hql_formatter.format_hql(hql)
        if self.log_sql:
            logger.info("final_hive_hql = {}", final_hive_hql)
        return self.internal_process.call(["hive", "-e", final_hive_hql])

    def get_database_info(self, database_name):
        hql = self.hql_formatter.desc_database_hql(database_name)
        logger.info("Begin to run hql [desc database {}]", database_name)
        sout, serr, rc = self.execute(hql)
        rs_map = {}
        if rc == 0:
            db_def_col = splitAndStrip(sout, "\t")
            rs_map["db_name"] = db_def_col[0]
            rs_map["comment"] = db_def_col[1]
            rs_map["location"] = db_def_col[2]
            rs_map["owner_name"] = db_def_col[3]
            rs_map["owner_type"] = db_def_col[4]
            rs_map["parameters"] = db_def_col[5]
        else:
            logger.warn("Failed to desc hive db [{}], error message is \n{}", database_name, serr)
        return rs_map

    def get_tables(self, database_name):
        hql = self.hql_formatter.show_tables_hql(database_name)
        logger.info("Begin to run hql [show tables in {}]", database_name)
        sout, serr, rc = self.execute(hql)
        rs_list = []
        if rc == 0:
            table_list = splitAndStrip(sout, "\n")
            rs_list = filter_empty_lines(table_list)
        else:
            logger.error("Failed to get table list for hive db [{}], error message is \n{}", database_name, serr)
        return rs_list

    def get_hive_columns(self, database_name, table_name):
        """
        hive command: desc <table>
         would return values like: <column_name>\t<column_type>\t<desc>\n
         however, "desc" is optional !!

        So split "\n" to get column definition string like:
            product_key             varchar(50)
        Then split on the column definition string to get the <col,type,desc>

        :return:
        """
        hql = self.hql_formatter.desc_table_hql(database_name, table_name)
        logger.info("Begin to run hql [desc {}.{}]", database_name, table_name)
        desc_table_output, serr, rc = self.execute(hql)
        if rc != 0:
            logger.error("Failed to describe hive table: [{}.{}]", database_name, table_name)
            return []

        col_definition_list = splitAndStrip(desc_table_output, "\n")
        col_definition_list = filter_empty_lines(col_definition_list)
        logger.debug("len of col_definition_list is [{}].", len(col_definition_list))
        col_def = [splitAndStrip(col_definition, "\t") for col_definition in col_definition_list]
        col_vector_size = len(col_def[0])  # if "desc" available, size is 3, otherwise 2.
        if col_vector_size == 3:
            return [HiveColumn(col, type, desc) for (col, type, desc) in col_def]
        else:
            return [HiveColumn(col, type, None) for (col, type) in col_def]

    def get_table_ddl(self, database_name, table_name):
        """
        Return create table DDL

        :param database_name:
        :param table_name:
        :return:
        """
        hql = self.hql_formatter.show_create_table_hql(database_name, table_name)
        logger.info("Begin to run hql [show create table {}.{}]", database_name, table_name)
        sout, serr, rc = self.execute(hql)
        if rc != 0:
            logger.error("Failed to describe hive table: [{}.{}]", database_name, table_name)
            return ""
        return sout

    def drop_table(self, database_name, table_name, skipTrash=False):
        if skipTrash:
            hql = self.hql_formatter.drop_table_skip_trash_hql(database_name, table_name)
        else:
            hql = self.hql_formatter.drop_table_hql(database_name, table_name)
        logger.info("Begin to run hql [{}]", hql)
        sout, serr, rc = self.execute(hql)
        if rc != 0:
            logger.error("Failed to drop hive table: [{}.{}]", database_name, table_name)
            return ""
        return rc

    def drop_database(self, database_name, skipTrash=False):
        if skipTrash:
            table_list = self.get_tables(database_name)
            hql_list = [self.hql_formatter.drop_table_skip_trash_hql(database_name, table_name)
                        for table_name in table_list]
            hql = "\n ".join(hql_list)
        else:
            hql = self.hql_formatter.drop_database_hql(database_name)
        logger.info("Begin to run hql [{}]", hql)
        sout, serr, rc = self.execute(hql)
        if rc != 0:
            logger.error("Failed to drop hive database: [{}]", database_name)
            return ""
        return rc


def test_hive_meta(database_name="bakery_oracle_sitdb_int_20160630", table_name="sqoop_execution_batch"):
    hm = get_hive_meta()
    hql = "set ;"
    # test hql execution:
    sout, serr, rc = hm.execute(hql)
    logger.info("lengh of [set] command is {}.", len(sout))
    # test "show database"
    di = hm.get_database_info(database_name)
    logger.info("Location of hive database [{}] is [{}]", database_name, di["location"])
    # test table list
    table_list = hm.get_tables(database_name)
    logger.info("There are [{}] tables in [{}]:\n {}", len(table_list), database_name, "\n ".join(table_list))
    # test columns
    hiveColumns = hm.get_hive_columns(database_name, table_name)
    #  ==> For testing only ghh.pp_columns(hiveColumns)
    logger.info("Columns in table [{}] are:\n {}", table_name, "\n ".join([str(column) for column in hiveColumns]))
    # test DDL
    table_ddl = hm.get_table_ddl(database_name, table_name)
    logger.info("table DDL for table [{}.{}] is: \n{}", database_name, table_name, table_ddl)


print ("module %s Loaded..." % __name__)
