# coding: UTF-8


"""
COPYRIGHT (C) 2017 HSBC GBDS GLTc. ALL RIGHTS RESERVED.

No part of this publication may be reproduced, stored in a retrieval system,
or transmitted, on any form or by any means, electronic, mechanical, photocopying,
recording, or otherwise, without the prior written permission of GBDS.

Created By: Terence Feng
Created On: 2017-02-06

Amendment History:

Amended By       Amended On      Amendment Description
------------     -----------     ---------------------------------------------

"""

from gbdspy.commons import logging as gcl
from gbdspy.commons import util as gcu
from gbdspy.commons import process as gcp

__metaclass__ = type  # use new style class !


logger = gcl.get_logger(__name__)

def kinit():
    from subprocess import Popen, PIPE, STDOUT
    user = gcu.whoami()
    # kinit_cmd = "kinit -kt /home/{whoami}/.{whoami}-headless.keytab {whoami}".format(whoami=whoami())
    keytab = "/home/{whoami}/.{whoami}-headless.keytab".format(whoami=gcu.whoami())
    p = gcp.Process()
    (sout, serr, rc) = p.call(["kinit", "-kt", keytab, user])
    return rc


def kdestroy():
    p = gcp.Process()
    (sout, serr, rc) = p.call(["kdestroy"])
    return rc


def klist():
    p = gcp.Process()
    (sout, serr, rc) = p.call(["klist"])
    p.dump_msg()



# # alias kt="/hsbc/babar/uat/crypto_util/release/kerberos_ticket_init.sh `whoami`"
# alias kt="kinit -kt /home/$(whoami)/.$(whoami)-headless.keytab $(whoami) "



print ("module %s Loaded..." % __name__)
