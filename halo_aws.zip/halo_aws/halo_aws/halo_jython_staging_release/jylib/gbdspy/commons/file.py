# coding: UTF-8


"""
COPYRIGHT (C) 2017 HSBC GBDS GLTc. ALL RIGHTS RESERVED.

No part of this publication may be reproduced, stored in a retrieval system,
or transmitted, on any form or by any means, electronic, mechanical, photocopying,
recording, or otherwise, without the prior written permission of GBDS.

Created By: Terence Feng
Created On: 2017-02-06

Amendment History:

Amended By       Amended On      Amendment Description
------------     -----------     ---------------------------------------------

"""


# because using legacy jython-standalone-2.5.3.jar now.
from __future__ import with_statement

from gbdspy.commons import util as gcu;


# def read_config(fname):
#     with open(fname) as f:
#         content = f.readlines()
#     content = [x.strip() for x in content if not gcu.empty(x)]
#     return content

def read_config(fname):
    """ Read lines from file """
    with open(fname) as f:
        content = f.readlines()
    return content


def filter_empty_lines(lines):
    return [x.strip() for x in lines if x and not x.strip().startswith("#") and not gcu.empty(x)]


print ("module %s Loaded..." % __name__)