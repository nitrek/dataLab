# coding: UTF-8

"""
COPYRIGHT (C) 2017 HSBC GBDS GLTc. ALL RIGHTS RESERVED.

No part of this publication may be reproduced, stored in a retrieval system,
or transmitted, on any form or by any means, electronic, mechanical, photocopying,
recording, or otherwise, without the prior written permission of GBDS.

Created By: Terence Feng
Created On: 2017-02-06

Amendment History:

Amended By       Amended On      Amendment Description
------------     -----------     ---------------------------------------------

"""

# __all__ = ['empty', 'lower', 'print_class_path']
# __all__ = [ 'lower', 'print_class_path']

# import gbdspy.common.util as gcu
from gbdspy.commons import logging as gcl

__metaclass__ = type  # use new style class !

logger = gcl.get_logger(__name__)


def empty(s):
    """
    Check if str is empty or not

    :param s:
    :return:
    """
    return not (s and s.strip())


def lower(str):
    """
    safer lower() function, just in case parameter str is None.
    :param str:
    :return:
    """
    if str is None:
        return None
    else:
        return str.lower()


def splitAndStrip(strlist, separator="\t"):
    """
    split <col_name> <col_type> <col_desc> into list
    """
    return [ elem.strip() for elem in strlist.split(separator)]


def filter_empty_lines(lines):
    return [line.strip() for line in lines if line and not empty(line)]


def print_class_path():
    from java.lang import ClassLoader
    cl = ClassLoader.getSystemClassLoader()
    paths = map(lambda url: url.getFile(), cl.getURLs())
    # print paths
    for path in paths:
        print (path)
    print ("...", "the end", "...")


def pp(obj):
    """
    Pretty print
    :param obj:
    :return:
    """
    import pprint
    pprint.pprint(obj)


# e.g.: xload('gbdspy.common_util')
# 
def xload(module):
    """
    Reload module
    Not work so perfect ...
    :param module:
    :return:
    """
    # import importlib
    # importlib.reload(module)
    import sys
    # imp.reload(module)
    # reload(sys.modules['gbdspy.common_util'])
    reload(sys.modules[module])
    print ('xload() Ends...')


def whoami():
    """
    Get current user name

    :return:
    """
    import java.lang.System as jsys
    return jsys.getProperty('user.name')

def gen_salt(key_size=32):
    from com.hsbc.gbds.bigdata.common.util.aws import CryptoUtils
    crypto_utils = CryptoUtils.createAESCrypto()
    return crypto_utils.generateKey(key_size)


def plogger(func):
    """
    Decorator, used for as "@plogger"
    :param func:
    :return:
    """
    def inner(*args, **kwargs):
        logger.info("Arguments for function [{}] were {}, {}", func.__name__, args, kwargs)
        return func(*args, **kwargs)
    return inner

print ("module %s Loaded..." % __name__)
