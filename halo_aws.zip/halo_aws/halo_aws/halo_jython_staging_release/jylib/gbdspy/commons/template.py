# coding: UTF-8


"""
COPYRIGHT (C) 2017 HSBC GBDS GLTc. ALL RIGHTS RESERVED.

No part of this publication may be reproduced, stored in a retrieval system,
or transmitted, on any form or by any means, electronic, mechanical, photocopying,
recording, or otherwise, without the prior written permission of GBDS.

Created By: Terence Feng
Created On: 2017-02-06

Amendment History:

Amended By       Amended On      Amendment Description
------------     -----------     ---------------------------------------------

"""

from org.stringtemplate.v4 import STGroupString

from gbdspy.commons import exception as gce
from gbdspy.commons import logging as gcl

__metaclass__ = type  # use new style class !

logger = gcl.get_logger(__name__)

# import UserDict as ud


# import gbdspy.commons.template as gct
#
# hello = gct.StringTemplate("Hello, $name$")
# hello["name"] = "World"
# hello.render(hello)

# class StringTemplate(object):
# class StringTemplate(ud.UserDict):
class StringTemplate(dict):
    # def __init__(self, hive_database, table_name, columns=None, ddl=""):
    # public STGroupString(String sourceName, String text, char delimiterStartChar, char delimiterStopChar) {
    # def __init__(self, text, delimiterStartChar='{', delimiterStopChar='}', sourceName=""):
    # def __init__(self, text, delimiterStartChar='<', delimiterStopChar='>', sourceName=""):
    def __init__(self, text, delimiterStartChar='$', delimiterStopChar='$', sourceName=""):
        # ud.UserDict.__init__(self)
        # logger.info("type of StringTemplate is [{}]", type(StringTemplate))
        super(StringTemplate, self).__init__()
        self.sourceName = sourceName
        self.text = text
        # logger.info("HI")
        self.stGroupString = STGroupString(sourceName, text, delimiterStartChar, delimiterStopChar)
        # logger.info("HI - 02")

    def render(self, instance):
        # logger.info("start - render - Ends")
        st = self.stGroupString.getInstanceOf(instance)
        logger.debug(" st is [{}], instance is [{}], type of instance is [{}]", st, instance, type(instance))
        if st is None:
            raise gce.HaloException("Can't find instance [" + instance + "] in the template. ")

        attribute_map = st.getAttributes()
        for key in attribute_map:
            value = self.get(key, None)  # default value is None
            logger.debug("Init instance [{}] - add key [{}] with value [{}].", instance, key, str(value))
            st.add(key, value)

        return st.render()



class FileTemplate(StringTemplate):
    pass


print ("module %s Loaded..." % __name__)
