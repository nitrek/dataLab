#!/bin/bash


###
WORKING_DIR=`cd $(dirname $0) && pwd`
cd ${WORKING_DIR}
# echo "Change active directory to ${WORKING_DIR}"

# HALO_JYTHON_HOME=$(cd ${WORKING_DIR} && cd .. && pwd)
HALO_JYTHON_HOME=${WORKING_DIR}
# echo "HALO_JYTHON_HOME - ${HALO_JYTHON_HOME}"


./jython.sh jylib/aws_poc_app_hdp59.py "$@"
exit_code=$?

echo "\${exit_code} of aws_poc_app_hdp59.sh is ${exit_code}"
exit ${exit_code};


