



C:\workspaces\jython2017\aws_encryption_poc2\halo_jython_staging_release


### HDP59:
hdp59-cs-apprls@gbl11755 /hsbc/babar/uat/aws_encryption_poc2>


### tesLab:
cd /hsbc/babar/uat/
mkdir -p /hsbc/babar/uat/aws_encryption_poc2
cd /hsbc/babar/uat/aws_encryption_poc2 && ./jython.sh


