/**
 * COPYRIGHT (C) 2008 HSBC GLTc GB&M data engineering. ALL RIGHTS RESERVED.
 * 
 * No part of this publication may be reproduced, stored in a retrieval system,
 * or transmitted, on any form or by any means, electronic, mechanical,
 * photocopying, recording, or otherwise, without the prior written permission
 * of GB&M.
 * 
 * Created By: Terence Feng Created On: 2014-09-28
 * 
 * Amendment History:
 * 
 * Amended By Amended On Amendment Description ------------ -----------
 * ---------------------------------------------
 * 
 */
package com.hsbc.gbds.bigdata.common.util.aws;


public class CryptoConstant {
    /**
     * Used in keyGenerator.init(keySize, secureRandom), keyGenerator is object
     * not class generated key size "byte[16]" from
     * "byte[] keyBytes = key.getEncoded()"
     */
    public static final int KEY_SIZE_128 = 128;

    /**
     * Used in keyGenerator.init(keySize, secureRandom), keyGenerator is object
     * not class generated key size "byte[24]" from
     * "byte[] keyBytes = key.getEncoded()"
     */
    public static final int KEY_SIZE_192 = 192;

    /**
     * Used in keyGenerator.init(keySize, secureRandom), keyGenerator is object
     * not class generated key size "byte[32]" from
     * "byte[] keyBytes = key.getEncoded()"
     */
    public static final int KEY_SIZE_256 = 256;

    /**
     * Used in SecretKeyFactory.getInstance(algorithm), Every implementation of
     * the Java platform is required to support the following standard
     * KeyGenerator algorithms with the keysizes in parentheses:
     * 
     * AES (128) DES (56) DESede (168) HmacSHA1 HmacSHA256
     */
    public static final String KEY_GEN_ALGORITHM_AES = "AES"; // keySizes =
                                                              // 128.
    public static final String KEY_GEN_ALGORITHM_DES = "DES"; // keySizes = 56.
    public static final String KEY_GEN_ALGORITHM_DESede = "DESede"; // keySizes
                                                                    // = 168.
    public static final String KEY_GEN_ALGORITHM_HMACSHA1 = "HmacSHA1";
    public static final String KEY_GEN_ALGORITHM_HMACSHA256 = "HmacSHA256";
    // public static final String KEY_GEN_ALGORITHM_PBK = "PBKDF2WithHmacSHA1";

    /**
     * Used in Cipher.getInstance(transformation, provider)
     */
    public static final String TRANSFORMATION_AES = "AES/CBC/PKCS5Padding";

    /**
     * Used in Cipher.getInstance(transformation, provider)
     */
    public static final String PROVIDER_SUNJCE = "SunJCE";

    public static final String CHARSET_UTF8 = "UTF-8";
}
