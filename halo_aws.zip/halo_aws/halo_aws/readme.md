
# AWS Encryption POC

## config:

Assume the project is deployed into "/hsbc/babar/uat/aws_encryption_poc2" 

Refer to "config/mask_table.conf", set up the masking tables:

```properties
# Define column to be masked, use pattern:
# {database}.{table}.{column}

bakery_oracle_sitdb_int_20160630.sqoop_execution_batch.batch_name
bakery_oracle_sitdb_int_20160630.SQOOP_EXECUTION_BATCH.sub_batch_name

bakery_oracle_sitdb_int_20160630.sqoop_execution_log.batch_name
bakery_oracle_sitdb_int_20160630.sqoop_execution_log.sub_batch_name

```

## The target encrypted hive database
The target encrypted hive database is the same as orginal database with "__crypto" postfix.

e.g.: For "bakery_oracle_sitdb_int_20160630", its target database is "bakery_oracle_sitdb_int_20160630__crypto".


## Usage:

Assume the project is deployed into "/hsbc/babar/uat/aws_encryption_poc2" 

```bash
cd /hsbc/babar/uat/aws_encryption_poc2
./init.sh

./aws_poc_app.sh mask
./aws_poc_app.sh copy
./aws_poc_app.sh re-mask
./aws_poc_app.sh cleanup

```

## Features:
* Support pii column level data masking.
* Support copying none pii tables to target database.
* Support text format.
* Support threading.
* Support gzipped compression.
* support parameters:  mask / copy / re-mask / cleanup



## How to interactive programming 

Reload files after file changes ...

```python
import pprint as pp ;
import sys

pp.pprint(sys.modules)
gcu.xload('gbdspy.commons.file')
```


```python

content = gcf.read_config('config/mask_table.conf')

type(content)
pp.pprint(content)

```


## Misc Items:

1) salt_value is 64 bit, generated within program, NEVER ever save into files or even logs.
    But so far, only "hive command line" is used, but not beeline, if using "ps aux" the generated salt_value might be inspected.

2) Log files could be found under "logs" folder.

