#!/bin/bash


### 
WORKING_DIR=`cd $(dirname $0) && pwd`
cd ${WORKING_DIR}
echo "Change active directory to ${WORKING_DIR}"

# HALO_JYTHON_HOME=$(cd ${WORKING_DIR} && cd .. && pwd)
HALO_JYTHON_HOME=${WORKING_DIR}
echo "HALO_JYTHON_HOME - ${HALO_JYTHON_HOME}"


APP_MAIN_CLASS=org.python.util.jython

## setup classpath:
HALO_JYTHON_CLASSPATH=${WORKING_DIR}
HALO_JYTHON_CLASSPATH=${HALO_JYTHON_CLASSPATH}:${WORKING_DIR}/config
HALO_JYTHON_CLASSPATH=${HALO_JYTHON_CLASSPATH}:${HALO_JYTHON_HOME}/lib/*
HALO_JYTHON_CLASSPATH=${HALO_JYTHON_CLASSPATH}:${HALO_JYTHON_HOME}/jylib/
HALO_JYTHON_CLASSPATH=${HALO_JYTHON_CLASSPATH}:${HADOOP_CLASSPATH}

export HALO_JYTHON_CLASSPATH

echo HALO_JYTHON_CLASSPATH=${HALO_JYTHON_CLASSPATH}
java -cp ${HALO_JYTHON_CLASSPATH} ${APP_MAIN_CLASS} -Dpython.console=org.python.util.InteractiveConsole "$@"
exit_code=$?

echo "\${exit_code} is ${exit_code}"
exit ${exit_code};
