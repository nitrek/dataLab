



C:\workspaces\jython2017\aws_encryption_poc2\halo_jython_staging_release


### HDP59:
hdp59-cs-apprls@gbl11755 /hsbc/babar/uat/aws_encryption_poc2>


### tesLab:
cd /hsbc/babar/uat/
mkdir -p /hsbc/babar/uat/aws_encryption_poc2
cd /hsbc/babar/uat/aws_encryption_poc2 && ./jython.sh


### clojure:

(defn pcp []
  (let [classpaths (seq (.getURLs (java.lang.ClassLoader/getSystemClassLoader)))]
    (map println classpaths)))

(defn pcp []
    (->> (java.lang.ClassLoader/getSystemClassLoader)
        (.getURLs )
        seq 
        (map #(.getPath %) )
        pprint))

    
    
(use 'com.hsbc.gbds.bigdata.haloclj.aws :reload-all :verbose)
(use 'com.hsbc.gbds.bigdata.haloclj.hive :reload-all :verbose)

(foo :hi)
(zoo :hi)

(import 'com.hsbc.gbds.bigdata.haloclj.hive.HiveColumn)
(import 'com.hsbc.gbds.bigdata.haloclj.hive.HiveTable)
(import 'com.hsbc.gbds.bigdata.haloclj.hive.HiveDatabase)


------------------------------------ Jython:
from com.hsbc.gbds.bigdata.haloclj import aws
from com.hsbc.gbds.bigdata.haloclj import hive

from com.hsbc.gbds.bigdata.haloclj.hive import HiveColumn
from com.hsbc.gbds.bigdata.haloclj.hive import HiveTable
from com.hsbc.gbds.bigdata.haloclj.hive import HiveDatabase

dir(HiveColumn)
dir(HiveTable)
dir(HiveDatabase)


