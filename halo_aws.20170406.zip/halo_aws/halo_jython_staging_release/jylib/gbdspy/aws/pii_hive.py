# coding: UTF-8


"""
COPYRIGHT (C) 2017 HSBC GBDS GLTc. ALL RIGHTS RESERVED.

No part of this publication may be reproduced, stored in a retrieval system,
or transmitted, on any form or by any means, electronic, mechanical, photocopying,
recording, or otherwise, without the prior written permission of GBDS.

Created By: Terence Feng
Created On: 2017-02-06

Amendment History:

Amended By       Amended On      Amendment Description
------------     -----------     ---------------------------------------------

"""

from gbdspy.commons import logging as gcl
from gbdspy.commons import template as gct
from gbdspy.commons.util import lower  ## so that lower() / empty() is visible
from gbdspy.hdp import hive as ghh

__metaclass__ = type  # use new style class !

logger = gcl.get_logger(__name__)

TPL_CREATE_TABLE_DDL = """
hive_orc_ddl(database_name, location, full_table, columns, compress_config) ::= <<

create database if not exists `<database_name>`
<location> ;

use `<database_name>` ;
<compress_config>

CREATE TABLE IF NOT EXISTS `<full_table>`
(
  <columns:{column| `<column.column_name; format="upper">` <column.data_type>}; separator="\n, " >
)
STORED AS ORC
TBLPROPERTIES ("orc.compress"="SNAPPY") ;
>>



hive_text_ddl(database_name, location, full_table, columns, compress_config) ::= <<

create database if not exists `<database_name>`
<location> ;

use `<database_name>` ;
<compress_config>

CREATE TABLE IF NOT EXISTS `<full_table>`
(
  <columns:{column| `<column.column_name; format="upper">` <column.data_type>}; separator="\n, " >
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n'
TBLPROPERTIES ('serialization.null.format'='') ;

>>

"""

# HIVE_COMPRESS_CONFIG_CMD = """
#
# set mapred.compress.map.output=true ;
# set mapred.map.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec ;
# set mapred.output.compression.type=BLOCK ;
# set mapred.output.compress=true ;
# set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec ;
#
# """


HIVE_COMPRESS_CONFIG_CMD = """
set mapred.output.compress=true;
set hive.exec.compress.output=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;
"""

TPL_HIVE_DATA_MASKING_DML = """
data_masking_dml(ctx, columns, compress_config) ::= <<

add jar <ctx.udf_jar_path>;
CREATE TEMPORARY FUNCTION gbds_sha2 AS '<ctx.udf_class>';

set hive.execution.engine=tez ;
<compress_config>

insert into table `<ctx.target_db>`.`<ctx.target_table>`
select <columns; separator="\n , " >
from `<ctx.source_db>`.`<ctx.source_table>`  ;
>>

"""

TPL_HIVE_DATA_COPY_DML = """
data_copy_dml(ctx, columns, compress_config) ::= <<

set hive.execution.engine=tez ;
<compress_config>

insert into table `<ctx.target_db>`.`<ctx.target_table>`
select <columns; separator="\n , " >
from `<ctx.source_db>`.`<ctx.source_table>`  ;
>>

"""


class PIIHiveTable(ghh.HiveTable):
    def __init__(self, database_name, table_name, app_ctx):
        super(PIIHiveTable, self).__init__(database_name, table_name)
        if app_ctx is None:
            raise Exception("Unexpected null app_cts.")
        self.app_ctx = app_ctx
        logger.debug("app_ctx = {}", app_ctx)  # should not be empty.
        self.target_database_name = self.app_ctx.format_target_database_name(self.database_name)
        self.target_table_name = self.app_ctx.format_target_table_name(self.table_name)
        self.pii_column_set = set([])
        self._updatedHiveColumns = None  # data type would be list of HiveColumn.

    def add_pii_column(self, pii_column_name):
        lower_column_name = lower(pii_column_name)
        self.pii_column_set.add(lower_column_name)  # case insensitive

    def _convert_pii_column_types(self):
        if self._updatedHiveColumns is not None:
            return self._updatedHiveColumns
        upd_columns = []
        for column in self.hiveColumns:
            upd_column = column
            if column.column_name in self.pii_column_set:
                # set data type to string.
                upd_column = ghh.HiveColumn(column.column_name, "string", column.desc)
                logger.info("In hive table [{}], pii column is {}, data type is {}, convert to string by default.",
                            self.full_table_name, column.column_name, column.data_type)
            upd_columns.append(upd_column)
        self._updatedHiveColumns = upd_columns
        return self._updatedHiveColumns

    updatedHiveColumns = property(_convert_pii_column_types)

    def _populate_target_database_location(self):
        location = self.hiveDatabase.location
        ## Location would be like:
        # hdfs://wdctestlab0040-fe1.systems.uk.hsbc:8020/apps/hive/warehouse/\
        # bakery_oracle_jennya_int/bakery_oracle_sitdb_int_20160630.db
        return location.replace(self.database_name.strip() + ".db", self.target_database_name.strip() + ".db")

    def generate_table_ddl(self, stored_format):
        target_full_table_name = ghh.get_full_table_name(self.target_database_name, self.target_table_name)
        if lower(stored_format) == "orc":
            tpl = "hive_orc_ddl"
        else:
            tpl = "hive_text_ddl"
        # new hive database would be in the same encryption of old database.
        location = self._populate_target_database_location()
        location = " location '{loc}' ".format(loc=location)
        logger.info("Start to generate ddl for table [{}], preferred stored format is [{}], string tempate is [{}].",
                    target_full_table_name, stored_format, tpl)
        _st = gct.StringTemplate(TPL_CREATE_TABLE_DDL, "<", ">")
        _st["database_name"] = self.target_database_name
        _st["location"] = location
        _st["full_table"] = target_full_table_name
        # need to translate to map for stringtemplate access.
        _st["columns"] = [column.toMap() for column in self.updatedHiveColumns]
        _st["compress_config"] = HIVE_COMPRESS_CONFIG_CMD
        return _st.render(tpl)

    def generate_data_masking_hql(self, salt_value, salt_size="512"):
        _st = gct.StringTemplate(TPL_HIVE_DATA_MASKING_DML, "<", ">")
        udf_jar_path = self.app_ctx.udf_jar_path
        udf_class = self.app_ctx.mask_udf_class
        _st["ctx"] = {"udf_jar_path": udf_jar_path, "udf_class": udf_class,
                      "target_db": self.target_database_name, "target_table": self.target_table_name,
                      "source_db": self.database_name, "source_table": self.table_name,
                      "salt_size": salt_size, "salt_value": salt_value
                      }
        _st["columns"] = self._gen_columns_definitions(salt_value, salt_size)
        _st["compress_config"] = HIVE_COMPRESS_CONFIG_CMD
        return _st.render("data_masking_dml")

    def generate_data_copy_hql(self):
        _st = gct.StringTemplate(TPL_HIVE_DATA_COPY_DML, "<", ">")
        udf_jar_path = self.app_ctx.udf_jar_path
        udf_class = self.app_ctx.mask_udf_class
        _st["ctx"] = {"target_db": self.target_database_name, "target_table": self.target_table_name,
                      "source_db": self.database_name, "source_table": self.table_name,
                      }
        _st["columns"] = [column.column_name for column in self.hiveColumns]
        _st["compress_config"] = HIVE_COMPRESS_CONFIG_CMD
        return _st.render("data_copy_dml")

    def _gen_columns_definitions(self, salt_value, salt_size):
        col_defs = []
        for col in self.hiveColumns:
            if col.column_name in self.pii_column_set:
                # col_def = "gbds_sha2(cast({column_name} as string), '{salt_value}', {salt_size})".format(
                col_def = "gbds_sha2(cast({column_name} as string), '{salt_value}', {salt_size})".format(
                    column_name=col.column_name, salt_value=salt_value, salt_size=salt_size
                )
                col_defs.append(col_def)
            else:
                col_defs.append(col.column_name)
        logger.debug("self.pii_column_set is: {}, col_defs is {}", str(self.pii_column_set), str(col_defs))
        return col_defs


class PIIHiveDatabase(ghh.HiveDatabase):
    def __init__(self, database_name, app_ctx):
        super(PIIHiveDatabase, self).__init__(database_name)
        self.piiHiveTables = []  # a list of PIIHiveTable
        self._nonePIIHiveTables = None
        if app_ctx is None:
            raise Exception("Unexpected null app_cts.")
        self.app_ctx = app_ctx
        self.target_database_name = self.app_ctx.format_target_database_name(self.database_name)

    def add_pii_table(self, pii_table):
        """
        :param pii_table: instance of PIIHiveTable.
        :return:
        """
        self.piiHiveTables.append(pii_table)

    def _get_none_pii_tables(self):
        """
        :return: a list of HiveTable
        """
        if self._nonePIIHiveTables is None:
            pii_table_names = [lower(table.table_name) for table in self.piiHiveTables]
            pii_table_name_set = set(pii_table_names)
            # Need to return PIIHiveTable instead of HiveTable, because the most available fields in PIIHiveTable,
            #     like target_database_name
            # self._nonePIIHiveTables = [ghh.HiveTable(self.database_name, table_name)
            self._nonePIIHiveTables = [PIIHiveTable(self.database_name, table_name, self.app_ctx)
                                       for table_name in self.get_table_names()
                                       if table_name not in pii_table_name_set]
        return self._nonePIIHiveTables

    nonePIIHiveTables = property(_get_none_pii_tables)


print ("module %s Loaded..." % __name__)
