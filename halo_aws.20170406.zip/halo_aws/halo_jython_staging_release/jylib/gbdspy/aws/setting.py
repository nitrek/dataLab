# coding: UTF-8


"""
COPYRIGHT (C) 2017 HSBC GBDS GLTc. ALL RIGHTS RESERVED.

No part of this publication may be reproduced, stored in a retrieval system,
or transmitted, on any form or by any means, electronic, mechanical, photocopying,
recording, or otherwise, without the prior written permission of GBDS.

Created By: Terence Feng
Created On: 2017-02-06

Amendment History:

Amended By       Amended On      Amendment Description
------------     -----------     ---------------------------------------------

"""

import os

from gbdspy.aws import default_config as gad
from gbdspy.aws import pii_hive as gap
from gbdspy.commons import exception as gce
from gbdspy.commons import file as gcf
from gbdspy.commons import logging as gcl
from gbdspy.hdp import hive as ghh
from java.util import Collections, ArrayList

__metaclass__ = type  # use new style class !

logger = gcl.get_logger(__name__)


def get_app_ctx(working_dir=None, stored_format=None, target_database_postfix=None, aws_s3_bucket=None):
    return AppCtx(working_dir=working_dir,
                  stored_format=stored_format,
                  target_database_postfix=target_database_postfix,
                  aws_s3_bucket=aws_s3_bucket)


def alternative(option1, option2):
    if option1 is not None:
        return option1
    else:
        logger.info(" -- Use default value [{}]", option2)
        return option2


class TableRpt(object):
    def __init__(self, pii_table, sout, serr, rc, action_code):
        self.pii_table = pii_table
        self.sout = sout
        self.serr = serr
        self.rc = rc
        self.action_code = action_code

    def strkey(self):
        return self.pii_table.strkey()  # return full table name.


class SummaryReport(object):
    def __init__(self):
        self.data_list = Collections.synchronizedList(ArrayList())

    def register_status(self, pii_table, sout, serr, rc, action_code):
        tableRpt = TableRpt(pii_table, sout, serr, rc, action_code)
        self.data_list.add(tableRpt)

    def register_mask_ddl(self, pii_table, sout, serr, rc):
        self.register_status(pii_table, sout, serr, rc, "mask_ddl")

    def register_mask_dml(self, pii_table, sout, serr, rc):
        self.register_status(pii_table, sout, serr, rc, "mask_dml")

    def register_copy_ddl(self, pii_table, sout, serr, rc):
        self.register_status(pii_table, sout, serr, rc, "copy_ddl")

    def register_copy_dml(self, pii_table, sout, serr, rc):
        self.register_status(pii_table, sout, serr, rc, "copy_dml")

    def _sort_set_msg(self, name_set):
        name_list = list(name_set)
        name_list.sort()
        return "\n\t".join(name_list)

    def report_mask_status(self):
        mask_list = [table_rpt for table_rpt in self.data_list
                     if table_rpt.action_code in ["mask_ddl", "mask_dml"]]
        failed_tables = [table.strkey() for table in mask_list if table.rc != 0]
        full_tables_set = set([table.strkey() for table in mask_list])
        failed_table_set = set(failed_tables)
        success_table_set = full_tables_set - failed_table_set
        fsort = self._sort_set_msg
        if len(failed_table_set) == 0:
            logger.info(
                "The overall masking processing is successful, there were totally {} tables procesed, they are:\n\t{}",
                len(full_tables_set), fsort(full_tables_set))
        else:
            logger.error("The masking processing was done, but {} out of {} tables failed, " +
                         "failed tables are:\n\t{}\n\n, successful tables are:\n\t{} ",
                         len(failed_table_set), len(full_tables_set),
                         fsort(failed_table_set), fsort(success_table_set))
        return len(failed_table_set)

    def report_copy_status(self):
        copy_list = [table_rpt for table_rpt in self.data_list
                     if table_rpt.action_code in ["copy_ddl", "copy_dml"]]
        failed_tables = [table.strkey() for table in copy_list if table.rc != 0]
        full_tables_set = set([table.strkey() for table in copy_list])
        failed_table_set = set(failed_tables)
        success_table_set = full_tables_set - failed_table_set
        fsort = self._sort_set_msg
        if len(failed_table_set) == 0:
            logger.info(
                "The overall copy processing is successful, there were totally {} tables procesed, they are:\n\t{}",
                len(full_tables_set), fsort(full_tables_set))
        else:
            logger.error("The copy processing was done, but {} out of {} tables failed, " +
                         "failed tables are:\n\t{}\n\n, successful tables are:\n\t{} ",
                         len(failed_table_set), len(full_tables_set),
                         fsort(failed_table_set), fsort(success_table_set))
        return len(failed_table_set)


class AppCtx(object):
    def __init__(self, working_dir=None,
                 stored_format=None, target_database_postfix=None, aws_s3_bucket=None):
        import subprocess, os
        self.working_dir = alternative(working_dir, os.getcwd())
        logger.info("Current active working directory is [{}].", self.working_dir)
        self.target_database_postfix = alternative(target_database_postfix, gad.TARGET_DATABASE_POSTFIX)
        logger.info("Target database postfix is [{}].", self.target_database_postfix)
        self.parallel_process = gad.PARALLEL_PROCESS
        self.thread_number = gad.THREAD_NUMBER
        self.keep_alive_days = gad.KEEP_ALIVE_DAYS
        if not self.parallel_process:
            logger.info("Parallel process flag is [{}].", self.parallel_process)
        else:
            logger.info("Parallel process flag is [{}], thread number is [{}], keep alive days [{}].",
                        self.parallel_process, self.thread_number, self.keep_alive_days)
        # self.udf_jar_path = gad.
        self.stored_format = alternative(stored_format, gad.STORED_FORMAT)
        logger.info("stored format is [{}]", self.stored_format)
        # use os.path.expanduser() to support "~" as user home folder
        self.aws_crypto_key_path = os.path.expanduser(gad.AWS_CRYPTO_KEY_PATH)
        self.aws_crypto_path = os.path.expanduser(gad.AWS_CRYPTO_PATH)
        self.aws_s3_bucket = alternative(aws_s3_bucket, gad.AWS_S3_BUCKET)
        logger.info("default aws crypto key path is [{}], crypto path is [{}].",
                    self.aws_crypto_key_path, self.aws_crypto_path)
        logger.info("default aws_s3_bucket is [{}].", self.aws_s3_bucket)
        self.config_file_path = gad.CONF_FILE_PATH
        self.mask_udf_jar_file = gad.MASK_UDF_JAR_FILE
        self.mask_udf_class = gad.MASK_UDF_CLASS
        self.salt_size = gad.SALT_SIZE
        # salt_value = gcu.gen_salt(8)  # gen_salt is from util.py
        self.udf_jar_path = gad.get_udf_jar_path(self.working_dir, self.mask_udf_jar_file)
        # load config data from file:
        self._mask_table_config_map = self.get_mask_table_config_map()
        self.pii_table_map = self._mask_table_config_map
        self.pii_database_map = {}
        self.rpt = SummaryReport()
        # update shell env map:
        self.shell_env_map = os.environ.copy()

    def update_aws_cipher(self, aws_access_key_id, aws_secret_access_key):
        self.shell_env_map["HTTPS_PROXY"] = "http://dtp.aws.cloud.uk.hsbc:443"
        self.shell_env_map["AWS_DEFAULT_REGION"] = "eu-west-2"
        self.shell_env_map["AWS_ACCESS_KEY_ID"] = aws_access_key_id
        self.shell_env_map["AWS_SECRET_ACCESS_KEY"] = aws_secret_access_key

    def format_target_database_name(self, database_name):
        return database_name + self.target_database_postfix
        # return database_name + "__crypto3" # for terence testing only.

    def format_target_table_name(self, table_name):
        return table_name

    def get_mask_table_config_map(self):
        return load_mask_table_config(self.config_file_path, self)

    def get_pii_database(self, database_name):
        return self.pii_database_map[database_name]

    def init_pii_database(self, database_name):
        pii_db = None
        key = ghh.normalize_name(database_name)
        if key in self.pii_database_map:
            pii_db = self.pii_database_map[key]
        else:  # not in map:
            pii_db = gap.PIIHiveDatabase(key, self)
            self.pii_database_map[key] = pii_db
        return pii_db

    def print_config_map(self):
        tmap = self.pii_table_map
        for table_name in tmap:  # <name, PIIHiveTable>
            pii_table = tmap[table_name]
            # print(table_name, pii_table.pii_column_set)
            logger.info(" => table [{}] 's pii column set is {}.", table_name, str(pii_table.pii_column_set))

    def post_init(self):
        """
        For masking, no need to call this function,
        For copying, need to call this function.
        :return:
        """

        def tnames(table_list):
            names = [table.full_table_name for table in table_list]
            return "\n\t".join(names)

        pii_tables = self.pii_table_map.values()
        for pii_table in pii_tables:
            piiHiveDatabase = self.init_pii_database(pii_table.database_name)
            piiHiveDatabase.add_pii_table(pii_table)

        # PIIHiveDatabase's piiHiveTables have been intialized, force to init their hiveTables & nonePIIHiveTables
        for database_name in self.pii_database_map:
            pdb = self.pii_database_map[database_name]
            logger.debug("pii hive database: [{}], type is [{}]", pdb.database_name, type(pdb))
            logger.info("Hive database [{}] has [{}] tables in total, [{}] are PII tables, while [{}] none pii tables",
                        database_name, len(pdb.hiveTables), len(pdb.piiHiveTables), len(pdb.nonePIIHiveTables))
            for hiveTable in pdb.hiveTables:
                hiveTable.set_hive_database(pdb)
            logger.debug("PII tables: [{}] in total:\n\t{}",
                         len(pdb.piiHiveTables), tnames(pdb.piiHiveTables))
            logger.debug("None PII tables: [{}] in total:\n\t{}",
                         len(pdb.nonePIIHiveTables), tnames(pdb.nonePIIHiveTables))


def init_pii_hive_table(database_name, table_name, app_ctx, ht_map=None):
    ht = gap.PIIHiveTable(database_name, table_name, app_ctx)
    if ht_map is not None:
        key = ht.strkey()
        if key not in ht_map:  # not exist in map
            ht_map[key] = ht
        else:
            ht = ht_map[key]
    return ht


def load_mask_table_config(config_file_path, app_ctx):
    content = gcf.read_config(config_file_path)
    content = gcf.filter_empty_lines(content)
    ht_map = {}
    # split "db.table.column" to a tuple (db, table, column)
    b = [db_tbl_col.split(".") for db_tbl_col in content]
    for col_def in b:
        if len(col_def) != 3:
            raise gce.IllegalConfiguration("Wrong config, it should be in format: {database}.{table}.{column}")
        pii_ht = init_pii_hive_table(col_def[0], col_def[1], app_ctx, ht_map)
        pii_ht.add_pii_column(col_def[2])
    return ht_map


# def test_setting():
#     # from gbdspy.aws import copy_table as gac
#     # from gbdspy.aws import mask_table as gam
#     # from gbdspy.aws import setting as gas
#     app_ctx = get_app_ctx()
#     app_ctx.pii_database_map
#     len(app_ctx.pii_database_map)
#     app_ctx.pii_table_map
#     len(app_ctx.pii_table_map)
#
#     app_ctx.print_config_map()
#     # force loading hive database tables ...
#     app_ctx.post_init()
#
#     db = app_ctx.get_pii_database("bakery_oracle_sitdb_int_20160629")
#     db = app_ctx.get_pii_database("bakery_oracle_sitdb_int_20160630")
#     db.hiveTables
#     len(db.hiveTables)
#     db.piiHiveTables
#     db.nonePIIHiveTables


# if __name__ == "__main__":
#     pass

print ("module %s Loaded..." % __name__)
