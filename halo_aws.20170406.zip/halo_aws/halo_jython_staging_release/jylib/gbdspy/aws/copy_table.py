# coding: UTF-8


"""
COPYRIGHT (C) 2017 HSBC GBDS GLTc. ALL RIGHTS RESERVED.

No part of this publication may be reproduced, stored in a retrieval system,
or transmitted, on any form or by any means, electronic, mechanical, photocopying,
recording, or otherwise, without the prior written permission of GBDS.

Created By: Terence Feng
Created On: 2017-02-06

Amendment History:

Amended By       Amended On      Amendment Description
------------     -----------     ---------------------------------------------

"""

from gbdspy.commons import logging as gcl
from gbdspy.hdp import hive as ghh
from gbdspy.hdp import kerberos as ghk
from java.lang import Runnable
from java.util.concurrent import Executors, TimeUnit

__metaclass__ = type  # use new style class !

logger = gcl.get_logger(__name__)


def process_none_pii_table_copy(piiHiveTable, app_ctx):
    """
    Execute copy actions, and log down status.
    :param piiHiveTable:
    :return:
    """
    full_table_name = piiHiveTable.full_table_name
    serr1, serr2 = "", ""
    try:
        logger.info("Begin to execute DDL for table [{}] data copy.", full_table_name)
        # => step 1: generate table DDL
        ddl = piiHiveTable.generate_table_ddl(app_ctx.stored_format)
        logger.info("ddl is \n{}", ddl)
        sout, serr1, rc = piiHiveTable.execute(ddl)
        app_ctx.rpt.register_copy_ddl(piiHiveTable, sout, serr1, rc)
        # => step 2: generate table copy DML
        dml = piiHiveTable.generate_data_copy_hql()
        sout, serr2, rc = piiHiveTable.execute(dml)
        app_ctx.rpt.register_copy_ddl(piiHiveTable, sout, serr2, rc)
    except (Exception,) as e:
        err_msg = "\n".join([serr1, serr2])
        logger.error("End data copy for table [{}], failed, error message were:\n{}", full_table_name, err_msg)
    else:
        logger.info("End data copy for table [{}].", full_table_name)


def populate_pending_copy_tables(pii_database, target_database_name):
    """

    :param pii_database:
    :param target_database_name:
    :return: a list of pending pii tables
    """
    # Table Filter 1: only process none PII hive Tables.
    nonePIIHiveTables = pii_database.nonePIIHiveTables
    # filter tables in target database:
    targetHiveDatabase = ghh.HiveDatabase(target_database_name)
    target_table_names = targetHiveDatabase.get_table_names()
    target_table_name_set = set(target_table_names)
    # Table Filter 2: ignore these ingested tables.
    pendingHiveTables = [hiveTable for hiveTable in nonePIIHiveTables
                         if hiveTable.table_name not in target_table_name_set]
    return pendingHiveTables


def copy_database_none_pii_tables(pii_database, target_database_name, app_ctx):
    pendingHiveTables = populate_pending_copy_tables(pii_database, target_database_name)
    # short alias names:
    database_name = pii_database.database_name
    # begin table processing:
    for piiHiveTable in pendingHiveTables:  # its internal object is PIIHiveTable
        logger.info("Copying table [{}] from hive database [{}] to [{}].",
                    piiHiveTable.table_name, database_name, target_database_name)
        process_none_pii_table_copy(piiHiveTable, app_ctx)


def __main_copy_none_pii_tables(app_ctx):
    import os
    logger.info("Current active working directory is [{}].", os.getcwd())
    ghk.kinit()
    ghk.klist()
    # app_ctx.post_init() # force init table lists in databases .

    for database_name in app_ctx.pii_database_map:
        pdb = app_ctx.get_pii_database(database_name)
        logger.debug("pii hive database: [{}], type is [{}]", pdb.database_name, type(pdb))
        logger.info(
            "Processing Hive database [{}], it has [{}] tables in total, [{}] are PII tables, while [{}] none pii tables",
            database_name, len(pdb.hiveTables), len(pdb.piiHiveTables), len(pdb.nonePIIHiveTables))
        target_database_name = app_ctx.format_target_database_name(database_name)
        # DB level copy:
        copy_database_none_pii_tables(pdb, target_database_name, app_ctx)


class TableCopyRunnable(Runnable):
    def __init__(self, pii_table, app_ctx):
        self.pii_table = pii_table
        self.app_ctx = app_ctx

    def run(self):
        logger.info("In TableMaskingRunnable - Processing table {}", self.pii_table.table_name)
        process_none_pii_table_copy(self.pii_table, self.app_ctx)
        logger.info("In TableMaskingRunnable - End processing table {}", self.pii_table.table_name)


def __main_copy_none_pii_tables_parallel(app_ctx):
    import os
    logger.info("Current active working directory is [{}].", os.getcwd())
    ghk.kinit()
    ghk.klist()
    # extract all pending tables in databases
    all_pending_tables = []
    for database_name in app_ctx.pii_database_map:
        pdb = app_ctx.get_pii_database(database_name)
        logger.debug("pii hive database: [{}], type is [{}]", pdb.database_name, type(pdb))
        target_database_name = app_ctx.format_target_database_name(database_name)
        pending_tables = populate_pending_copy_tables(pdb, target_database_name)
        logger.info(
            "Processing Hive database [{}], there were [{}] pending copy none pii tables.",
            database_name, len(pending_tables))
        all_pending_tables.extend(pending_tables)

    # parallelly copy tables:
    logger.info("Assambling [{}] pending copy none pii tables in [{}] hive databases. [Parallel].",
                len(all_pending_tables), len(app_ctx.pii_database_map))
    executor = Executors.newFixedThreadPool(app_ctx.thread_number)
    for pii_table in all_pending_tables:
        runner = TableCopyRunnable(pii_table, app_ctx)
        logger.info("Add table [{}] to execution pool.", pii_table.full_table_name)
        executor.execute(runner)
    executor.shutdown()
    executor.awaitTermination(app_ctx.keep_alive_days, TimeUnit.DAYS)
    logger.info("Table copy process has been completed !!")


def main_copy_none_pii_tables(app_ctx):
    error_rc = 0
    failed_table_count = 0
    try:
        if app_ctx.parallel_process:
            __main_copy_none_pii_tables_parallel(app_ctx)
        else:  # no threading.
            __main_copy_none_pii_tables(app_ctx)
        error_rc = 0
    except:
        error_rc = -1  # abnormal exit
        raise
    finally:
        failed_table_count = app_ctx.rpt.report_copy_status()
    return error_rc + failed_table_count


print ("module %s Loaded..." % __name__)
