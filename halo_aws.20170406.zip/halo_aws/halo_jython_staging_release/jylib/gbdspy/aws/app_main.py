# coding: UTF-8

"""
COPYRIGHT (C) 2017 HSBC GBDS GLTc. ALL RIGHTS RESERVED.

No part of this publication may be reproduced, stored in a retrieval system,
or transmitted, on any form or by any means, electronic, mechanical, photocopying,
recording, or otherwise, without the prior written permission of GBDS.

Created By: Terence Feng
Created On: 2017-02-17

Amendment History:

Amended By       Amended On      Amendment Description
------------     -----------     ---------------------------------------------

"""

import os
import sys
import traceback

from gbdspy.aws import copy_table as gac
from gbdspy.aws import mask_table as gam
from gbdspy.aws import upload_table as gau
from gbdspy.aws import setting as gas
from gbdspy.commons import logging as gcl
from gbdspy.commons.util import lower, Stopwatch

logger = gcl.get_logger(__name__)

ACTION_MASK = "mask"
ACTION_COPY = "copy"
ACTION_RE_MASK = "re-mask"
ACTION_CLEANUP = "cleanup"
ACTION_CIPHER = "cipher"
ACTION_UPLOAD = "upload"
ACTION_AWSCLI = "aws" # aws wrapper.

SUPPORTED_ACTIONS = [ACTION_MASK, ACTION_COPY, ACTION_RE_MASK, ACTION_CLEANUP, ACTION_CIPHER, ACTION_UPLOAD, ACTION_AWSCLI]


def app_help(argv):
    logger.error("Supported arguments are: [{}], but the arguments are: ",
                 " / ".join(SUPPORTED_ACTIONS))
    for idx, arg in enumerate(argv):
        # print (idx, arg)
        logger.error("  param[{}] is [{}] ", idx, arg)


def get_action_code(argv):
    if len(argv) <= 1: # the first arg is the py file name.
        logger.error("At least 2 parameter should be provideded.")
        app_help(argv)
        sys.exit(-1)
    action = lower(argv[1])
    if action not in SUPPORTED_ACTIONS:
        app_help(argv)
        sys.exit(-1)
    logger.info("get_action_code() - Action is [{}].", action)
    return action


def __main(argv, working_dir=None, stored_format=None, target_database_postfix=None, aws_s3_bucket=None):
    action_code = get_action_code(argv)
    app_ctx = gas.get_app_ctx(working_dir=os.getcwd(),
                              stored_format=stored_format,
                              target_database_postfix=target_database_postfix,
                              aws_s3_bucket=aws_s3_bucket)
    app_ctx.print_config_map()

    rc_code = 0

    # cipher action no need post_init(), process() then quit().
    if ACTION_CIPHER == action_code:
        logger.info("Processing action [{}]", ACTION_CIPHER)
        # app_ctx.post_init() # No need post_init().
        rc_code = gau.main_cipher(app_ctx)
        return rc_code
    elif ACTION_AWSCLI == action_code:
        logger.info("Processing action [{}]", ACTION_AWSCLI)
        # skip the first parameter:  python file
        # skip the second parameter: "aws"
        param_argv = argv[2:]
        rc_code = gau.main_awscli(app_ctx, param_argv)
        return rc_code
    elif ACTION_UPLOAD == action_code:
        logger.info("Processing action [{}]", ACTION_UPLOAD)
        app_ctx.post_init()
        # skip the first parameter:  python file
        # skip the second parameter: "aws"
        param_argv = argv[2:]
        rc_code = gau.main_upload(app_ctx, param_argv)
        return rc_code

    app_ctx.post_init()  # force init table list
    if ACTION_MASK == action_code:
        logger.info("Processing action [{}]", ACTION_MASK)
        rc_code = gam.main_mask_pii_tables(app_ctx)
    elif ACTION_COPY == action_code:
        logger.info("Processing action [{}]", ACTION_COPY)
        rc_code = gac.main_copy_none_pii_tables(app_ctx)
    elif ACTION_RE_MASK == action_code:
        # gac.main_copy_none_pii_tables(app_ctx)
        logger.info("Processing action [{}]", ACTION_RE_MASK)
        rc_code = gam.main_remask_mask_pii_tables(app_ctx)
    elif ACTION_CLEANUP == action_code:
        # gac.main_copy_none_pii_tables(app_ctx)
        logger.info("Processing action [{}]", ACTION_CLEANUP)
        rc_code = gam.main_cleanup(app_ctx)
    else:
        logger.error("Unknow action code [{}]", action_code)
    return rc_code


def main(argv, stored_format="text", target_database_postfix="__crypto", aws_s3_bucket=None):
    rc_code = 0
    stopwatch = Stopwatch()
    try:
        rc_code = __main(argv,
                         stored_format=stored_format,
                         target_database_postfix=target_database_postfix,
                         aws_s3_bucket=aws_s3_bucket)
    except:
        rc_code = 1
        logger.error("Error occurred: {}", str(traceback.format_exc()))
        logger.error("Execution info: {}", str(sys.exc_info()[0]))
        raise
    finally:
        stopwatch.stop()
        if rc_code == 0:
            logger.info("... Programme Ends successfully..., elapsed time - {}", str(stopwatch))
        else:
            logger.error("... Oooops, Programme Ends, but there were errors ..., elapsed time - {}", str(stopwatch))
        sys.exit(rc_code)


print ("module %s Loaded..." % __name__)
