# coding: UTF-8


"""
COPYRIGHT (C) 2017 HSBC GBDS GLTc. ALL RIGHTS RESERVED.

No part of this publication may be reproduced, stored in a retrieval system,
or transmitted, on any form or by any means, electronic, mechanical, photocopying,
recording, or otherwise, without the prior written permission of GBDS.

Created By: Terence Feng
Created On: 2017-02-06

Amendment History:

Amended By       Amended On      Amendment Description
------------     -----------     ---------------------------------------------

"""

# DEFAULT_CONFIG_FILE = 'config/mask_table.conf'
CONF_FILE_PATH = "config/mask_table.conf"
MASK_UDF_JAR_FILE = "gbds-hive-udf-0.0.1-hdp-2.2.jar"
MASK_UDF_CLASS = "com.hsbc.gbds.bigdata.hive.udf.GenericUDFSha2V1"
SALT_SIZE = 512
TARGET_DATABASE_POSTFIX = "__crypto"

# STORED_FORMAT="orc"
STORED_FORMAT="text"

PARALLEL_PROCESS = True
# PARALLEL_PROCESS=False

THREAD_NUMBER = 5
KEEP_ALIVE_DAYS = 1


AWS_CRYPTO_KEY_PATH = "~/.halo_aws/aws_crypto_key.property"
AWS_CRYPTO_PATH = "~/.halo_aws/aws_crypto.property"

## HDP59 testing:
# AWS_S3_BUCKET='dtp-281041766603-dataload/test'

## prod:
AWS_S3_BUCKET='dtp-281041766603-dataload/data'


def get_udf_jar_path(working_dir, udf_jar_file=MASK_UDF_JAR_FILE):
    return "{pwd}/lib_udf/{udf_jar_file}".format(pwd=working_dir, udf_jar_file=udf_jar_file)


print ("module %s Loaded..." % __name__)
