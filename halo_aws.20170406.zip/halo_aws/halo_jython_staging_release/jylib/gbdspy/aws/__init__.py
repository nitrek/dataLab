# coding: UTF-8

"""
COPYRIGHT (C) 2017 HSBC GBDS GLTc. ALL RIGHTS RESERVED.

No part of this publication may be reproduced, stored in a retrieval system,
or transmitted, on any form or by any means, electronic, mechanical, photocopying,
recording, or otherwise, without the prior written permission of GBDS.

Created By: Terence Feng
Created On: 2017-02-06

Amendment History:

Amended By       Amended On      Amendment Description
------------     -----------     ---------------------------------------------
Terence Feng     2017-02-17      Add __version__
Terence Feng     2017-03-06      support paramters for "upload" / "aws", update version to "1.1.1".

"""

# __version__ = "1.0"

__version__ = "1.1.1"

