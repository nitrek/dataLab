# coding: UTF-8


"""
COPYRIGHT (C) 2017 HSBC GBDS GLTc. ALL RIGHTS RESERVED.

No part of this publication may be reproduced, stored in a retrieval system,
or transmitted, on any form or by any means, electronic, mechanical, photocopying,
recording, or otherwise, without the prior written permission of GBDS.

Created By: Terence Feng
Created On: 2017-02-06

Amendment History:

Amended By       Amended On      Amendment Description
------------     -----------     ---------------------------------------------


### Usage:

from gbdspy import *
gcu.xload('gbdspy')
gbdspy_main()

"""

__metaclass__ = type  # use new style class !

import os
import subprocess as sp

from gbdspy.aws import copy_table as gac
from gbdspy.aws import mask_table as gam
from gbdspy.aws import setting as gas
from gbdspy.aws import pii_hive as gap
from gbdspy.commons import exception as gce
from gbdspy.commons import file as gcf
from gbdspy.commons import logging as gcl
from gbdspy.commons import process as gcp
from gbdspy.commons import template as gct
from gbdspy.commons import util as gcu
from gbdspy.hdp import hive as ghh
# from gbdspy.hdp import hivemeta as ghhm
from gbdspy.hdp import kerberos as ghk

pp = gcu.pp

logger = gcl.get_logger(__name__)

gbds_modules = [gac, gam, gas, gap, gce, gcf, gcl, gcp, gct, gcu, ghh, ghk]
for m in gbds_modules:
    logger.debug("Load file {} ", m.__file__)


def _init_dos2unix():
    print ("current path is [%s]" % os.getcwd())
    sp.call(["./init.sh"])


def _xl():
    """
    reload the pre-define modules
    :return:
    """
    from gbdspy.aws import copy_table as gac
    from gbdspy.aws import mask_table as gam
    from gbdspy.aws import setting as gas
    from gbdspy.aws import pii_hive as gap
    from gbdspy.commons import exception as gce
    from gbdspy.commons import file as gcf
    from gbdspy.commons import logging as gcl
    from gbdspy.commons import process as gcp
    from gbdspy.commons import template as gct
    from gbdspy.commons import util as gcu
    from gbdspy.hdp import hive as ghh
    # from gbdspy.hdp import hivemeta as ghhm
    from gbdspy.hdp import kerberos as ghk
    import sys

    for m in [gac, gam, gas, gap, gce, gcf, gcl, gcp, gct, gcu, ghh, ghk]:
        logger.debug("Load file {} ", m.__file__)
        gcu.xload(m.__name__)

    _gbds_modules = [m for m in sys.modules if m.startswith("gbdspy")]
    _gbds_modules.sort()
    pp(_gbds_modules)


def xl():
    _init_dos2unix()
    _xl()



def check_gct_template():
    tpl = """
outputFileName(table, ctx) ::= <<
cdc_hql_<ctx.currentTimestamp>/<table.lowerHiveTableName>.sql
>>
        """
    t = gct.StringTemplate(tpl, "<", ">")
    t["table"] = {"lowerHiveTableName": "hahaha_tbl"}
    t["ctx"] = {"currentTimestamp": "st01", "lowerHiveTableName": "02"}
    t["a"] = "b"

    logger.info("render template [{}], output is \n{}", 'outputFileName', t.render('outputFileName'))
    logger.info("render template [{}], output is \n{}", 'a', t.render('a'))


# def gen_pii_sql(pii_table, salt_value, salt_size="512"):
#     ddl = pii_table.generate_ddl()
#     logger.info("ddl is \n{}", ddl)
#     dml = pii_table.generate_data_masking_hql(salt_value, salt_size)
#     logger.info("dml is \n{}", dml)


# def gbdspy_main():
#     logger.info(" -- gbdspy __init__ main() --")
#     xl()
#     check_pii_map()
#     check_gct_template()
#     # helper functions:
#     # help(pp)
#     logger.info(" -- Ends --")
#
#
# if __name__ == "__main__":
#     gbdspy_main()
