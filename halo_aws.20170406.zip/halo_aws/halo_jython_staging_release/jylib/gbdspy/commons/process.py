# coding: UTF-8


"""
COPYRIGHT (C) 2017 HSBC GBDS GLTc. ALL RIGHTS RESERVED.

No part of this publication may be reproduced, stored in a retrieval system,
or transmitted, on any form or by any means, electronic, mechanical, photocopying,
recording, or otherwise, without the prior written permission of GBDS.

Created By: Terence Feng
Created On: 2017-02-06

Amendment History:

Amended By       Amended On      Amendment Description
------------     -----------     ---------------------------------------------

"""


import sys
from subprocess import Popen, PIPE

from gbdspy.commons import logging as gcl
from java.lang import Throwable

__metaclass__ = type  # use new style class !

logger = gcl.get_logger(__name__)


class Process(object):
    def __init__(self, log_cmd=False):
        # self.cmd = None
        # self.process = None
        self.stdout, self.stderr, self.returnCode = None, None, None
        self.log_cmd = log_cmd
        if self.log_cmd:
            logger.info("Property [log_cmd] is True.")

    # def call(self, stdout=PIPE, stderr=STDOUT, *args, **kwargs):
    def call(self, *args, **kwargs):
        """
        args is passed in as tuple.
        :param args:
        :return:
        """
        # self.process = Popen(["klist"], stdout=PIPE, stderr=STDOUT)
        # upd_kwargs = dict(**kwargs)
        # upd_kwargs["stdout"] = PIPE
        # upd_kwargs["stderr"] = STDOUT
        kwargs.setdefault('stdin', PIPE)
        kwargs.setdefault('stdout', PIPE)
        kwargs.setdefault('stderr', PIPE)
        kwargs.setdefault('close_fds', True)
        if self.log_cmd:
            logger.debug("kwargs is {}", str(kwargs))
        # cleanup variables first:
        self.stdout, self.stderr, self.returnCode = None, None, None
        try:
            _process = Popen(*args, **kwargs)
            # _process = Popen(*args, upd_kwargs)
            (self.stdout, self.stderr) = _process.communicate()
            self.returnCode = _process.wait()
        except (Throwable, Exception) as ex:
            if self.stderr is None:
                self.stderr = ex
            logger.error("Error occur: {}", ex)
            type, value, traceback = sys.exc_info()
            logger.error("Unexpected error: type [{}], value [{}], traceback - {}",
                         type, value, traceback)
            # print(traceback.format_exc())

        # logger.info("return code is {} for {}", self.returnCode, args)
        _args = args[0]
        if self.log_cmd:
            _args = args

        if self.returnCode == 0:
            logger.debug("""Command "{}" was executed successfully.""", _args)
        else:
            logger.error("Error occurred - return code is {} for {}, error msg is:\n{}",
                         self.returnCode, _args, self.stderr)
        return self.stdout, self.stderr, self.returnCode

    def print_stdout(self):
        print (self.stdout)

    def dump_msg(self):
        # print(self.stdout)
        logger.info("The return code is [{}], its standard output is \n{}",
                    self.returnCode, self.stdout)
        if self.returnCode != 0:
            logger.error("error output is \n{}", self.stderr)


print ("module %s Loaded..." % __name__)
