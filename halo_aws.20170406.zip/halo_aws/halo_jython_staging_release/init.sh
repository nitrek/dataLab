#!/bin/bash

find . -iname "*.sh" -exec dos2unix {} \;
find . -iname "*.py" -exec dos2unix {} \;

find . -iname "*.sh" -exec chmod a+x {} \;

chgrp -R hdp59-svc-grp-uat .
chmod -R 755 .


