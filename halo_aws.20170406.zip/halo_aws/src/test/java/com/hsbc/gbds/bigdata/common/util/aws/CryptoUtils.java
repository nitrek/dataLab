///**
// * COPYRIGHT (C) 2008 HSBC GLTc GB&M data engineering. ALL RIGHTS RESERVED.
// *
// * No part of this publication may be reproduced, stored in a retrieval system,
// * or transmitted, on any form or by any means, electronic, mechanical,
// * photocopying, recording, or otherwise, without the prior written permission
// * of GB&M.
// *
// * Created By: Terence Feng Created On: 2014-09-28
// *
// * Amendment History:
// *
// * Amended By Amended On Amendment Description ------------ -----------
// * ---------------------------------------------
// *
// */
//
//package com.hsbc.gbds.bigdata.common.util.aws;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import javax.crypto.Cipher;
//import javax.crypto.KeyGenerator;
//import javax.crypto.SecretKey;
//import javax.crypto.spec.IvParameterSpec;
//import javax.crypto.spec.SecretKeySpec;
//import java.security.NoSuchAlgorithmException;
//import java.security.SecureRandom;
//
//import static com.google.common.base.Preconditions.checkNotNull;
//
//public class CryptoUtils {
//    private static Logger logger = LoggerFactory.getLogger(CryptoUtils.class);
//
//    private static final String IV = "GBM_DE_BABAR__IV"; // Must be 16 bytes
//                                                         // long
//
//    private final String transformation;// e.g.: "AES/CBC/PKCS5Padding";
//    private final String provider; // e.g.: "SunJCE";
//    private final int keySize;
//    private final String keyGenAlgorithm;
//
//
//
//    public static CryptoUtils createAESCrypto() {
//        return new CryptoUtils(CryptoConstant.TRANSFORMATION_AES, CryptoConstant.PROVIDER_SUNJCE, CryptoConstant.KEY_SIZE_128,
//            CryptoConstant.KEY_GEN_ALGORITHM_AES);
//    }
//
//    public CryptoUtils(final String transformation, final String provider, final int keySize, final String keyGenAlgorithm) {
//        this.transformation = checkNotNull(transformation);
//        this.provider = checkNotNull(provider);
//        this.keySize = keySize;
//        this.keyGenAlgorithm = checkNotNull(keyGenAlgorithm);
//    }
//
//    public static String toHexString(final byte b[]) {
//        checkNotNull(b);
//        StringBuffer hexString = new StringBuffer();
//
//        for (int i = 0; i < b.length; i++) {
//            String plainText = Integer.toHexString(0xff & b[i]);
//
//            if (plainText.length() < 2) {
//                plainText = "0" + plainText;
//            }
//
//            hexString.append(plainText);
//        }
//        return hexString.toString();
//    }
//
//    public static byte[] convertHexString(final String ss) {
//        checkNotNull(ss);
//        byte digest[] = new byte[ss.length() / 2];
//
//        for (int i = 0; i < digest.length; i++) {
//            String byteString = ss.substring(2 * i, 2 * i + 2);
//            int byteValue = Integer.parseInt(byteString, 16);
//            digest[i] = (byte) byteValue;
//        }
//        return digest;
//    }
//
//    public byte[] encrypt(final String plainText, final String encryptionKey) throws Exception {
//        checkNotNull(plainText);
//        checkNotNull(encryptionKey);
//
//        Cipher cipher = Cipher.getInstance(this.transformation, this.provider);
//        SecretKey key = new SecretKeySpec(encryptionKey.getBytes(CryptoConstant.CHARSET_UTF8), this.keyGenAlgorithm);
//        cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(CryptoUtils.IV.getBytes(CryptoConstant.CHARSET_UTF8)));
//        return cipher.doFinal(plainText.getBytes(CryptoConstant.CHARSET_UTF8));
//    }
//
//    public String decrypt(final byte[] cipherText, final String encryptionKey) throws Exception {
//        checkNotNull(cipherText);
//        checkNotNull(encryptionKey);
//
//        Cipher cipher = Cipher.getInstance(this.transformation, this.provider);
//        SecretKeySpec key = new SecretKeySpec(encryptionKey.getBytes(CryptoConstant.CHARSET_UTF8), this.keyGenAlgorithm);
//        cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(CryptoUtils.IV.getBytes(CryptoConstant.CHARSET_UTF8)));
//        return new String(cipher.doFinal(cipherText), CryptoConstant.CHARSET_UTF8);
//    }
//
//    public String generateKey() {
//        SecretKey secretKey = checkNotNull(generateSecretKey());
//
//        // Get the bytes of the key
//        byte[] keyBytes = secretKey.getEncoded();
//        return toHexString(keyBytes);
//    }
//
//    public String generateKey(int maxLen) {
//        String key = generateKey();
//        if( key.length() > maxLen )
//        {
//            key = key.substring(0, maxLen);
//        }
//
//        return key;
//    }
//
//    public SecretKey generateSecretKey() {
//        SecretKey key = null;
//
//        try {
//            KeyGenerator keyGen = KeyGenerator.getInstance(this.keyGenAlgorithm);
//
//            SecureRandom random = new SecureRandom();
//            keyGen.init(this.keySize, random);
//            key = keyGen.generateKey();
//        } catch (NoSuchAlgorithmException ex) {
//            CryptoUtils.logger.error("Failed to generate secret key.", ex);
//        }
//
//        return key;
//    }
//
//    public SecretKey restoreSecretKey(final String key) throws Exception {
//        checkNotNull(key, "Key string should not be null");
//        SecretKey result = null;
//
//        // byte[] keyBytes = CryptoHelper.convertHexString(key);
//        byte[] keyBytes = key.getBytes(CryptoConstant.CHARSET_UTF8);
//        result = new SecretKeySpec(keyBytes, this.keyGenAlgorithm);
//
//        return result;
//    }
//
//    // public static final String transformation = "AES/CBC/PKCS5Padding";
//    // public static final String provider = "SunJCE";
//    //
//    // public static byte[] encrypt(String plainText, String encryptionKey)
//    // throws Exception
//    // {
//    // Cipher cipher = Cipher.getInstance(transformation, provider);
//    // SecretKey key = new SecretKeySpec(encryptionKey.getBytes("UTF-8"),
//    // "AES");
//    // cipher.init(Cipher.ENCRYPT_MODE, key, new
//    // IvParameterSpec(IV.getBytes("UTF-8")));
//    // return cipher.doFinal(plainText.getBytes("UTF-8"));
//    // }
//    //
//    // public static String decrypt(byte[] cipherText, String encryptionKey)
//    // throws Exception
//    // {
//    // Cipher cipher = Cipher.getInstance(transformation, provider);
//    // SecretKeySpec key = new SecretKeySpec(encryptionKey.getBytes("UTF-8"),
//    // "AES");
//    // cipher.init(Cipher.DECRYPT_MODE, key, new
//    // IvParameterSpec(IV.getBytes("UTF-8")));
//    // return new String(cipher.doFinal(cipherText), "UTF-8");
//    // }
//}
