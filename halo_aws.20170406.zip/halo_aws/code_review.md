
# Code Review

## gbds-hive-udf.zip
	
Hive UDF for pii column encryption.
    
1) Refer to "Cryptography and Key Management Standard.pdf "
    The approved hash algorithms includes SHA2 & SHA3

    And in our programme, SHA2 is used, with 512 hash size.

2) Refer to com.hsbc.gbds.bigdata.hive.udf.GenericUDFSha2V1

The key part is:
```java

import java.security.MessageDigest;


digest = MessageDigest.getInstance("SHA-" + len);

```

https://cwiki.apache.org/confluence/display/Hive/LanguageManual+UDF

hive in HDP2.4 supports sha2
string sha2(string/binary, int)

    Calculates the SHA-2 family of hash functions (SHA-224, SHA-256, SHA-384, and SHA-512) (as of Hive 1.3.0). The first argument is the string or binary to be hashed. The second argument indicates the desired bit length of the result, which must have a value of 224, 256, 384, 512, or 0 (which is equivalent to 256). SHA-224 is supported starting from Java 8. If either argument is NULL or the hash length is not one of the permitted values, the return value is NULL. Example: sha2('ABC', 256) = 'b5d4045c3f466fa91fe2cc6abe79232a1a57cdf104f7a26e716e0a1e2789df78'.

Here we learn and implement a new sha2, which support extra salt parameters.


```java

  public ObjectInspector initialize(ObjectInspector[] arguments) throws UDFArgumentException {
    // ...
    // check third parameter: sha size:
    if (arguments[PARAM_INDEX_SHA_SIZE] instanceof ConstantObjectInspector) {
      // Integer lenObj = getConstantIntValue(arguments, 1);
      Integer lenObj = SHA2UTIL.getConstantIntValue(arguments, PARAM_INDEX_SHA_SIZE);
      if (lenObj != null) {
        int len = lenObj.intValue();
        if (len == 0) {
          len = 256;
        }
        try {
          digest = MessageDigest.getInstance("SHA-" + len);
        } catch (NoSuchAlgorithmException e) {
          // ignore
        }
      }
    } else {
      throw new UDFArgumentTypeException(PARAM_INDEX_SHA_SIZE, SHA2UTIL.getFuncName() + " only takes constant as "
          + SHA2UTIL.getArgOrder(PARAM_INDEX_SHA_SIZE) + " argument");
    }
    // ...
  }
  
  public void mergeSaltAndUpdate(MessageDigest digest, byte[] originalBytes) {
    byte[] updBytes = Bytes.concat(originalBytes, this.saltBytes);
    digest.update(updBytes, 0, updBytes.length);
  }
  
```



3) usage:


assume the generated salt is: "27ea7066"



```
add jar /hsbc/babar/uat/aws_encryption_poc2/lib_udf/gbds-hive-udf-0.0.1-hdp-2.2.jar ;
CREATE TEMPORARY FUNCTION gbds_sha2 AS 'com.hsbc.gbds.bigdata.hive.udf.GenericUDFSha2V1' ;

set hive.cli.print.header=true;

select a.rank_acct_num, a.acct_comm_cde, a.cust_id_num, gbds_sha2(cast(cust_id_num as string), '27ea7066', 512)
from dtp_dev_ukdwh.dwc_acct_arr a
limit 10 ;


```


## aws_encryption_poc2.zip
Written in Jython, mainly focus on pii table masking and none pii table copying …




